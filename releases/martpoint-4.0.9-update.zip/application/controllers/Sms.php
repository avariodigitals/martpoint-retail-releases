<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sms extends MY_Controller {
	public function __construct(){
		parent::__construct();
		$this->load_global();
	}
	
	//Open SMS Form 
	public function index(){
		$this->permission_check('send_sms');
		$data=$this->data;
		$data['page_title']=$this->lang->line('send_sms');
		$data['content'] = $this->load->view('sms', $data, TRUE);
		$this->load->view('mp_layout', $data);
	}


	//Create Message
	public function send_message(){
		$this->permission_check('send_sms');
		$data=$this->data;
		$this->load->model('sms_model');
		$mobile = $this->input->post('mobile', TRUE);
		$message = $this->input->post('message', TRUE);
		$result= $this->sms_model->send_sms($mobile,$message);
		echo $result;
	}

	
	//Open SMS API Form 
	public function api(){
		
		$this->permission_check('sms_settings');
		$data=$this->data;
		$data['page_title']=$this->lang->line('sms_api');
		$data['content'] = $this->load->view('sms-api', $data, TRUE);
		$this->load->view('mp_layout', $data);
	}

	//UPDATE SMS API
	public function api_update(){
		$this->permission_check_with_msg('sms_settings');
		$this->load->model('sms_model');
    	echo $this->sms_model->api_update();
	}
	public function send_SMS_by_Twilio(){
		$this->load->model('twilio_model');
		$this->twilio_model->index();
	}
}

