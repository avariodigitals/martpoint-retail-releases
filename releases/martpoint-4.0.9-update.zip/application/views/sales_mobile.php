<!DOCTYPE html>
<html>

<head>
<!-- FORM CSS CODE -->
<?php include"comman/code_css.php"; ?>
<!-- </copy> -->
<!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="<?php echo $theme_link; ?>plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
<style type="text/css">
table.table-bordered > thead > tr > th {
/* border:1px solid black;*/
text-align: center;
}
.table > tbody > tr > td, 
.table > tbody > tr > th, 
.table > tfoot > tr > td, 
.table > tfoot > tr > th, 
.table > thead > tr > td, 
.table > thead > tr > th 
{
padding-left: 2px;
padding-right: 2px;  

}

/* ===== MOBILE RESPONSIVE ===== */
  /* Stack all form columns vertically */
  #sales-form .form-group > [class*="col-"],
  #sales-form .row > [class*="col-"],
  #sales-form [class*="col-sm-"],
  #sales-form [class*="col-md-"] {
    width: 100% !important;
    float: none !important;
    display: block !important;
    padding-left: 8px;
    padding-right: 8px;
    box-sizing: border-box;
  }
  /* Left-align labels */
  #sales-form .control-label {
    text-align: left !important;
    padding-top: 8px;
    padding-bottom: 4px;
    font-size: 13px;
    margin-bottom: 0;
    display: block;
  }
  /* Touch-friendly inputs */
  #sales-form .form-control,
  #sales-form .select2-container--default .select2-selection--single {
    min-height: 44px;
    font-size: 15px;
    width: 100% !important;
  }
  #sales-form .input-group {
    display: flex;
    width: 100%;
  }
  #sales-form .input-group .form-control {
    min-height: 44px;
    flex: 1;
  }
  #sales-form .btn {
    min-height: 44px;
    padding: 10px 14px;
    font-size: 14px;
  }
  /* Item search header: stack */
  #sales-form .col-md-8.col-md-offset-2 {
    width: 100% !important;
    margin-left: 0 !important;
    float: none !important;
  }
  #sales-form .col-md-8.col-md-offset-2 .input-group {
    margin-bottom: 8px;
  }
  /* Item table: horizontal scroll, no min-width */
  #sales-form .table-responsive {
    overflow-x: auto !important;
    -webkit-overflow-scrolling: touch;
    width: 100% !important;
    max-width: 100% !important;
    border: none !important;
    display: block !important;
  }
  /* Make the box containing the table not overflow */
  #sales-form .box .box-body {
    overflow-x: auto !important;
    -webkit-overflow-scrolling: touch;
    padding: 8px;
  }
  #sales_table {
    width: 100% !important;
    min-width: 0 !important;
    max-width: 100% !important;
  }
  #sales_table th,
  #sales_table td {
    min-width: 0 !important;
    white-space: nowrap;
    padding: 4px 4px;
    font-size: 12px;
  }
  #sales_table th { white-space: normal; }
  #sales_table input,
  #sales_table select,
  #sales_table .form-control {
    width: 100% !important;
    min-width: 0 !important;
    font-size: 12px;
    min-height: 34px;
  }
  #sales_table .input-group {
    width: 100%;
  }
  /* Customer input group: make room for addon */
  #sales-form #customer_id + .input-group-addon,
  #sales-form .input-group-addon {
    width: auto;
    min-width: 38px;
    text-align: center;
  }
  #sales-form .input-group .select2-container {
    flex: 1;
  }
  /* Coupon row: stack */
  #sales-form .coupon_type,
  #sales-form .coupon_value {
    display: block;
    width: 100%;
    float: none !important;
    text-align: left;
  }
  /* Item table cell inputs */
  #sales_table .input-group {
    width: 100%;
    min-width: 0 !important;
  }
  #sales_table .input-group .form-control,
  #sales_table .input-group .input-group-addon,
  #sales_table .input-group .btn {
    min-width: 0 !important;
    padding-left: 4px;
    padding-right: 4px;
    height: 34px;
  }
  /* Fix the price_type select min-width */
  #price_type {
    min-width: 0 !important;
    width: 100% !important;
  }
  /* Totals table: full width, no float */
  #sales-form table.col-md-9 {
    width: 100% !important;
    float: none !important;
    display: table;
  }
  #sales-form table.col-md-9 th {
    padding-left: 10px !important;
  }
  /* Payment section: stack all columns */
  #sales-form .payments_div .col-md-4,
  #sales-form .payments_div .col-md-6,
  #sales-form .payments_div .col-md-8,
  #sales-form .payments_div .col-md-12 {
    width: 100% !important;
    float: none !important;
    display: block !important;
    margin-bottom: 10px;
  }
  #sales-form .payments_div .row {
    margin-left: 0;
    margin-right: 0;
  }
  #sales-form .payments_div .select2-container {
    width: 100% !important;
  }
  /* Payments table: horizontal scroll */
  #payments_table {
    display: block;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    white-space: nowrap;
  }
  #payments_table th,
  #payments_table td {
    white-space: nowrap;
    padding: 8px 6px;
  }
  /* Box footer buttons: stack */
  #sales-form .box-footer .btn,
  #sales-form .box-footer .btn-group .btn {
    display: block;
    width: 100%;
    margin-bottom: 8px;
    min-height: 48px;
    font-size: 15px;
  }
  #sales-form .box-footer .btn:last-child,
  #sales-form .box-footer .btn-group .btn:last-child {
    margin-bottom: 0;
  }

  #sales-form { font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
  #sales_table { font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
  #sales_table thead.custom_thead .bg-primary { background: #F1F5F9 !important; color: #334155 !important; border-bottom: 2px solid #E2E8F0; }
  #sales_table thead th { font-weight: 600; font-size: 11px; text-transform: uppercase; color: #64748B; }
  #sales_table tbody td { color: #334155; }

/* Extra mobile fixes */
  #sales-form .control-label.pull-left,
  #sales-form .control-label.pull-right {
    float: none !important;
    display: block !important;
    width: 100% !important;
    padding-left: 8px;
    padding-right: 8px;
  }
  #sales-form .form-group > .col-sm-4,
  #sales-form .form-group > .col-md-4,
  #sales-form .form-group > .col-xs-4,
  #sales-form .form-group > .col-sm-3,
  #sales-form .form-group > .col-md-3,
  #sales-form .form-group > .col-xs-3 {
    width: 100% !important;
    float: none !important;
    display: block !important;
  }
  .mp-fab-wrapper {
    display: none !important;
  }
</style>
<style>
  /* === Mobile Quick Sale Revamp === */
  .main-sidebar, .main-header, .content-header, .main-footer, .navbar, .sidebar-toggle { display: none !important; }
  .content-wrapper, .right-side { margin-left: 0 !important; width: 100% !important; }
  .content { padding: 0 !important; background: #F1F5F9 !important; }
  #sales-form { font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
  .mp-mobile-topbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 16px;
    background: #fff;
    border-bottom: 1px solid #E2E8F0;
  }
  .mp-mobile-topbar h1 { font-size: 22px; font-weight: 700; margin: 0; color: #0F172A; }
  .mp-mobile-topbar .sub { font-size: 13px; color: #64748B; margin-top: 2px; }
  .mp-mobile-topbar .avatar {
    width: 38px; height: 38px; border-radius: 50%; background: #E0E7FF; color: #0057FF;
    display: flex; align-items: center; justify-content: center; font-weight: 600; font-size: 14px;
  }
  .mp-mobile-box { background: #fff; border-radius: 16px; padding: 16px; margin: 12px 16px; border: 1px solid #E2E8F0; box-shadow: 0 1px 3px rgba(0,0,0,0.04); }
  .mp-form-label { font-size: 14px; font-weight: 500; color: #0F172A; margin-bottom: 6px; display: block; }
  #sales-form .form-control, #sales-form .select2-container--default .select2-selection--single { border-radius: 14px; border: 1px solid #E2E8F0; min-height: 54px; font-size: 16px; background: #fff; }
  #sales-form .input-group-addon { border-radius: 14px; border: 1px solid #E2E8F0; background: #fff; }
  .mp-search-bar {
    display: flex; align-items: center; background: #F1F5F9; border-radius: 14px; padding: 14px 16px; border: 1px solid #E2E8F0;
  }
  .mp-search-bar input { border: none; background: transparent; flex: 1; font-size: 16px; outline: none; }
  .mp-save-btn {
    width: calc(100% - 32px);
    margin: 16px;
    padding: 18px;
    border: none;
    border-radius: 14px;
    background: #0057FF;
    color: white;
    font-size: 17px;
    font-weight: 600;
    display: block;
    text-align: center;
  }
  .mp-total-row {
    display: flex; justify-content: space-between; align-items: center;
    margin: 16px; padding: 20px; background: #fff; border-radius: 16px; border: 1px solid #E2E8F0;
  }
  .mp-total-row .label { font-size: 16px; color: #64748B; }
  .mp-total-row .value { font-size: 26px; font-weight: 700; color: #0057FF; }
  #sales-form #sales_table thead { display: none; }
  #sales-form #sales_table tbody tr { display: block; background: #fff; border-radius: 16px; margin-bottom: 10px; padding: 12px; border: 1px solid #E2E8F0; }
  #sales-form #sales_table tbody td { display: block; width: 100% !important; min-width: 0 !important; border: none; padding: 4px 0; }
  #sales-form #sales_table .form-control { min-height: 38px; }
</style>
</head>


<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
 
 
 <?php include"sidebar.php"; ?>
 
 <?php
    if(isset($sales_id)){

      //Edit
      $q2 = $this->db->query("select * from db_sales where id=$sales_id");
      $customer_id=$q2->row()->customer_id;
      $sales_date=show_date($q2->row()->sales_date);
      $due_date=(!empty($q2->row()->due_date)) ? show_date($q2->row()->due_date) : '';
      $sales_status=$q2->row()->sales_status;
      $warehouse_id=$q2->row()->warehouse_id;
      $reference_no=$q2->row()->reference_no;
      $discount_input=store_number_format($q2->row()->discount_to_all_input,0);
      $discount_type=$q2->row()->discount_to_all_type;
      $other_charges_input=store_number_format($q2->row()->other_charges_input,0);
      $other_charges_tax_id=$q2->row()->other_charges_tax_id;
      $sales_note=$q2->row()->sales_note;
      $store_id=$q2->row()->store_id;
      
      $init_code=$q2->row()->init_code;
      $count_id=$q2->row()->count_id;

      $coupon_id=$q2->row()->coupon_id;
      $coupon_code = (!empty($coupon_id)) ? get_customer_coupon_details($coupon_id)->code : '';
      $invoice_terms=$q2->row()->invoice_terms;


      $items_count = $this->db->query("select count(*) as items_count from db_salesitems where sales_id=$sales_id")->row()->items_count;
      $save_operation = false;
    }
    else if(isset($quotation_id) && !empty($quotation_id)){
      //NEW
      $q2 = $this->db->query("select * from db_quotation where id=$quotation_id");
      $customer_id=$q2->row()->customer_id;
      $sales_date=show_date($q2->row()->quotation_date);
      $due_date='';
      $sales_status='';
      $warehouse_id=$q2->row()->warehouse_id;
      $reference_no=$q2->row()->reference_no;
      $discount_input=store_number_format($q2->row()->discount_to_all_input,0);
      $discount_type=$q2->row()->discount_to_all_type;
      $other_charges_input=store_number_format($q2->row()->other_charges_input,0);
      $other_charges_tax_id=$q2->row()->other_charges_tax_id;
      $sales_note=$q2->row()->quotation_note;
      $store_id=$q2->row()->store_id;

      //$sales_code = get_init_code('sales');
      $init_code=get_only_init_code('sales');
      $count_id=get_last_count_id('db_sales');

      $items_count = $this->db->query("select count(*) as items_count from db_quotationitems where quotation_id=$quotation_id")->row()->items_count;
      $coupon_code='';

      $store_details = get_store_details($store_id);
      $invoice_terms =$store_details->invoice_terms;
      $save_operation = true;
    }
    else{
      //NEW
      $customer_id  = $sales_date = $sales_status = $warehouse_id =$due_date=
      $reference_no  =$coupon_code=
      $other_charges_input          = $other_charges_tax_id = $store_id =
      $discount_type  = $sales_note = '';
      $sales_date=show_date(date("d-m-Y"));
      $discount_input = $this->db->select("sales_discount")->get('db_store')->row()->sales_discount;
      $discount_input = ($discount_input==0) ? 0 : $discount_input;
      
      $init_code=get_only_init_code('sales');
      $count_id=get_last_count_id('db_sales');

      $store_details = get_store_details();
      $invoice_terms =$store_details->invoice_terms;
      $save_operation = true;
    }
   
   
    ?>

 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <div class="mp-mobile-topbar">
      <div>
        <h1>Quick Sale</h1>
        <div class="sub"><?= $init_code . ' ' . $count_id; ?></div>
      </div>
      <div class="avatar"><?= strtoupper(substr($this->session->userdata('display_name') ?: 'U',0,2)); ?></div>
    </div>
    <!-- **********************MODALS***************** -->
    <?php include"modals/modal_customer.php"; ?>
    <?php include"modals/modal_item.php"; ?>
    <?php include"modals/modal_item_or_service.php"; ?>
   <?php /*include"modals/modal_service.php";*/ ?>
    <!-- **********************MODALS END***************** -->
    <!-- Content Header (Page header) -->
    <section class="content-header">
         <h1>
            <?=$page_title;?>
            <small>Add/Update Sales</small>
         </h1>
         <ol class="breadcrumb">
            <li><a href="<?php echo $base_url; ?>dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo $base_url; ?>sales"><?= $this->lang->line('sales_list'); ?></a></li>
            <li><a href="<?php echo $base_url; ?>sales/add"><?= $this->lang->line('new_sales'); ?></a></li>
            <li class="active"><?=$page_title;?></li>
         </ol>
      </section>

    <!-- Main content -->
     <section class="content">
               <div class="row">
                <!-- ********** ALERT MESSAGE START******* -->
               <?php include"comman/code_flashdata.php"; ?>
               <?php include"modals/modal_sales_item.php"; ?>
               
               <!-- ********** ALERT MESSAGE END******* -->
                  <!-- right column -->
                  <div class="col-xs-12">
                     <!-- Horizontal Form -->
                     <div class="box box-primary mp-mobile-box" >
                        <!-- style="background: #68deac;" -->
                        
                        <!-- form start -->
                         <!-- OK START -->
                        <?= form_open('#', array('class' => 'form-horizontal', 'id' => 'sales-form', 'enctype'=>'multipart/form-data', 'method'=>'POST'));?>
                           <input type="hidden" id="base_url" value="<?php echo $base_url;; ?>">
                           <input type="hidden" value='1' id="hidden_rowcount" name="hidden_rowcount">
                           <input type="hidden" value='0' id="hidden_update_rowid" name="hidden_update_rowid">
                           <input type="hidden" value='Final' id="sales_status" name="sales_status">

                          <?php if(isset($quotation_id)) {?>
                           <input type="hidden" id="quotation_id" name="quotation_id" value="<?php echo $quotation_id;; ?>">
                           <?php } ?>

                           <div class="box-body">
                              <!-- Store Code -->
                              <?php 
                              /*if(store_module() && is_admin()) {$this->load->view('store/store_code',array('show_store_select_box'=>true,'store_id'=>$store_id,'div_length'=>'col-sm-3')); }else{*/
                                echo "<input type='hidden' name='store_id' id='store_id' value='".get_current_store_id()."'>";
                              /*}*/
                              ?>
                              <!-- Store Code end -->
                              <!-- Branch Code -->
                              
                              <!-- Branch Code end -->
                              <div class="form-group">
                                 <label for="warehouse_id" class="col-xs-12 control-label"><?= $this->lang->line('branch'); ?><label class="text-danger">*</label></label>
                                 <div class="col-xs-12">
                                    <select class="form-control select2 " id="warehouse_id" name="warehouse_id" >
                                       <?= get_warehouse_select_list($warehouse_id,get_current_store_id());?>
                                    </select>
                                    <span id="warehouse_id_msg" style="display:none" class="text-danger"></span>
                                 </div>
                                 <label for="init_code" class="col-xs-12 control-label"><?= $this->lang->line('sales_code'); ?><label class="text-danger">*</label></label>
                                 <div class="col-xs-12" style="padding-right:0;">
                                    <input type="text" value="<?= $init_code; ?>" class="form-control" style='font-size:18px; padding:6px 8px;' id="init_code" name="init_code" placeholder="" <?= !is_admin() ? 'readonly' : ''; ?>>
                                       <span id="init_code_msg" style="display:none" class="text-danger"></span>
                                 </div>
                                 <div class="col-xs-12" style="padding-left:1;">
                                    <input type="text" style='font-size:18px; padding:6px 8px;' value="<?php echo  $count_id; ?>" class="form-control no_special_char" id="count_id" name="count_id" placeholder="" <?= !is_admin() ? 'readonly' : ''; ?>>
                                       <span id="count_id_msg" style="display:none" class="text-danger"></span>
                                 </div>

                                 
                            <!-- <div class="col-xs-12">
                                <div class="checkbox">
                                    <label toggle='tooltip' title="Check for Non FSTR Bill Creation">
                                        <input type="checkbox" name="" checked="" />
                                        <span></span>
                                        Non FSTR
                                    </label>
                                </div>
                            </div> -->


                                 
                              </div>
                              <div class="form-group">
                                 <label for="customer_id" class="col-xs-12 control-label"><?= mp_label('customer'); ?> Name<label class="text-danger">*</label></label>
                                 <div class="col-xs-12">
                                    <div class="input-group">
                                       <select class="form-control select2" id="customer_id" name="customer_id"  style="width: 100%;">
                                       </select>
                                       <span class="input-group-addon pointer" data-toggle="modal" data-target="#customer-modal" title="New <?= mp_label('customer'); ?>?"><i class="fa fa-user-plus text-primary fa-lg"></i></span>
                                    </div>
                                    <div id="walkin-warning" class="alert alert-warning" style="display:none;margin-top:6px;padding:6px 10px;font-size:12px;">
                                      <i class="fa fa-exclamation-triangle"></i> <strong>Walk-in <?= mp_label('customer'); ?>:</strong> Must pay in full — any payment method allowed. Credit is not allowed.
                                    </div>
                                    <span id="customer_id_msg" style="display:none" class="text-danger"></span>
                                    <lable><?= $this->lang->line('previous_due'); ?> :<label class="customer_previous_due text-red" style="font-size: 18px;">0.00</label></lable>
                                 </div>
                                 <label for="sales_date" class="col-xs-12 control-label"><?= $this->lang->line('sales_date'); ?> <label class="text-danger">*</label></label>
                                 <div class="col-xs-12">
                                    <div class="input-group date">
                                       <div class="input-group-addon">
                                          <i class="fa fa-calendar"></i>
                                       </div>
                                       <input type="text" class="form-control datepicker"  id="sales_date" name="sales_date" readonly onkeyup="shift_cursor(event,'sales_status')" value="<?= $sales_date;?>">
                                    </div>
                                    <span id="sales_date_msg" style="display:none" class="text-danger"></span>
                                 </div>
                              </div>
                              <div class="form-group">
                                 <label for="reference_no" class="col-xs-12 control-label"><?= $this->lang->line('reference_no'); ?> </label>
                                 <div class="col-xs-12">
                                    <input type="text" value="<?php echo  $reference_no; ?>" class="form-control " id="reference_no" name="reference_no" placeholder="" >
                  <span id="reference_no_msg" style="display:none" class="text-danger"></span>
                                 </div>
                                <label for="due_date" class="col-xs-12 control-label"><?= $this->lang->line('due_date'); ?></label>
                                 <div class="col-xs-12">
                                    <div class="input-group date">
                                       <div class="input-group-addon">
                                          <i class="fa fa-calendar"></i>
                                       </div>
                                       <input type="text" class="form-control datepicker"  id="due_date" name="due_date"  value="<?= $due_date;?>">
                                    </div>
                                    <span id="due_date_msg" style="display:none" class="text-danger"></span>
                                 </div>
                              </div>
                              
                           </div>
                           <!-- /.box-body -->
                           
                           <div class="row">
                              <div class="col-xs-12">
                                <div class="col-xs-12">
                                  <div class="box">
                                    <div class="box-info">
                                      <div class="box-header">
                                        <div class="col-xs-12 col-md-offset-2 d-flex justify-content" >
                                          <div class="input-group">
                                                <span class="input-group-addon" title="Price Type"><i class="fa fa-tag"></i></span>
                                                <select class="form-control" id="price_type" name="price_type" style="min-width:120px;">
                                                  <option value="wholesale" selected>Wholesale</option>
                                                  <option value="retail">Retail (MRP)</option>
                                                </select>
                                          </div>
                                          <div class="input-group" style="margin-top:4px;">
                                                <span class="input-group-addon" title="Select Items"><i class="fa fa-barcode"></i></span>
                                                 <input type="text" class="form-control " placeholder="Item name/Barcode/Itemcode" autofocus id="item_search">
                                                 <span class="input-group-addon pointer text-green show_item_service" title="Click to Add New Item or Service"><i class="fa fa-plus"></i></span>

                                                 


                                              </div>
                                        </div>
                                      </div>
                                      <div class="box-body">
                                        <div class="table-responsive" style="width: 100%">
                                        <table class="table table-hover table-bordered" style="width:100%" id="sales_table">
                                             <thead class="custom_thead">
                                                <tr class="bg-primary" >
                                                   <th rowspan='2' style="width:15%"><?= $this->lang->line('item_name'); ?></th>
                                                 
                                                   <th rowspan='2' style="width:10%;"><?= $this->lang->line('quantity'); ?></th>
                                                   <th rowspan='2' style="width:10%"><?= $this->lang->line('unit_price'); ?></th> 
                                                   <th rowspan='2' style="width:10%"><?= $this->lang->line('discount'); ?>(<?= $CI->currency() ?>)</th>
                                                   <th rowspan='2' style="width:10%"><?= $this->lang->line('tax_amount'); ?></th>
                                                   <th rowspan='2' style="width:5%"><?= $this->lang->line('tax'); ?></th>
                                                   <th rowspan='2' style="width:7.5%"><?= $this->lang->line('total_amount'); ?></th>
                                                   <th rowspan='2' style="width:7.5%"><?= $this->lang->line('action'); ?></th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                               
                                             </tbody>
                                          </table>
                                      </div>
                                      </div>
                                    </div>
                                  </div>
                                  

                                </div>
                              </div>
                              
                              <div class="col-xs-12">
                                <div class="row">
                                    <div class="col-xs-12">
                                       <div class="form-group">
                                          <label for="" class="col-xs-12 control-label"><?= $this->lang->line('quantity'); ?></label>    
                                          <div class="col-xs-12">
                                             <label class="control-label total_quantity text-success" style="font-size: 15pt;">0</label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>

                                 

                                 <div class="row">
                                    <div class="col-xs-12">
                                       <div class="form-group">
                                          <label for="other_charges_input" class="col-xs-12 control-label"><?= $this->lang->line('other_charges'); ?></label>    
                                          <div class="col-xs-12">
                                             <input type="text" class="form-control text-right only_currency" id="other_charges_input" name="other_charges_input" onkeyup="final_total();" value="<?php echo  $other_charges_input; ?>">
                                          </div>
                                          <div class="col-xs-12">
                                             <select class="form-control " id="other_charges_tax_id" name="other_charges_tax_id" onchange="final_total();" style="width: 100%;">
                                                <?= get_tax_select_list($other_charges_tax_id,get_current_store_id());?>
                                             </select>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-xs-12">
                                       <div class="form-group">
                                          <label for="other_charges_input" class="col-xs-12 control-label"><?= $this->lang->line('discountCouponCode'); ?></label>    
                                          <div class="col-xs-12">
                                             <input type="text" class="form-control" id="coupon_code" name="coupon_code" value="<?=$coupon_code; ?>">

                                             <label class="control-label"><?= $this->lang->line('couponType'); ?>:<span class="coupon_type">---</span></label>
                                             <label class="control-label"><?= $this->lang->line('couponValue'); ?>:<span class="coupon_value">0.00</span></label>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-xs-12 div1 hide">
                                       <div class="form-group">    
                                          <div class="col-xs-12 col-sm-offset-4">
                                             <div class="alert text-left msg_color">
                                              <strong id="coupon_code_msg">
                                              </strong>
                                            </div>
                                          </div>
                                       </div>
                                    </div>

                                 </div>

                                 
                                 <div class="row">
                                    <div class="col-xs-12">
                                       <div class="form-group">
                                          <label for="discount_to_all_input" class="col-xs-12 control-label"><?= $this->lang->line('discount_on_all'); ?></label>    
                                          <div class="col-xs-12">
                                             <input type="text" class="form-control  text-right only_currency" id="discount_to_all_input" name="discount_to_all_input" onkeyup="enable_or_disable_item_discount();" value="<?= store_number_format($discount_input,0); ?>">
                                          </div>
                                          <div class="col-xs-12">
                                             <select class="form-control" onchange="final_total();" id='discount_to_all_type' name="discount_to_all_type">
                                                <option value='in_percentage'>Per%</option>
                                                <option value='in_fixed'>Fixed</option>
                                             </select>
                                          </div>
                                          <!-- Dynamicaly select Supplier name -->
                                          <script type="text/javascript">
                                             <?php if($discount_type!=''){ ?>
                                                 document.getElementById('discount_to_all_type').value='<?php echo  $discount_type; ?>';
                                             <?php }?>
                                          </script>
                                          <!-- Dynamicaly select Supplier name end-->
                                       </div>
                                    </div>
                                 </div>
                                <div class="row">
                                    <div class="col-xs-12">
                                       <div class="form-group">
                                          <label for="sales_note" class="col-xs-12 control-label"><?= $this->lang->line('note'); ?></label>    
                                          <div class="col-xs-12">
                                             <textarea class="form-control text-left" id='sales_note' name="sales_note"><?= $sales_note; ?></textarea>
                                            <span id="sales_note_msg" style="display:none" class="text-danger"></span>
                                          </div>
                                       </div>
                                    </div>
                                 </div>

                                 
                              </div>
                              

                              <div class="col-xs-12">
                                 <div class="row">
                                    <div class="col-xs-12">
                                       <div class="form-group">
                                           
                                          <table  class="col-xs-12">
                                             <tr>
                                                <th class="text-right" style="font-size: 17px;"><?= $this->lang->line('subtotal'); ?></th>
                                                <th class="text-right" style="padding-left:10px;font-size: 17px;">
                                                   <h4><b id="subtotal_amt" name="subtotal_amt">0.00</b></h4>
                                                </th>
                                             </tr>
                                             <tr>
                                                <th class="text-right" style="font-size: 17px;"><?= $this->lang->line('other_charges'); ?></th>
                                                <th class="text-right" style="padding-left:10px;font-size: 17px;">
                                                   <h4><b id="other_charges_amt" name="other_charges_amt">0.00</b></h4>
                                                </th>
                                             </tr>
                                             <tr>
                                                <th class="text-right" style="font-size: 17px;"><?= $this->lang->line('couponDiscount'); ?></th>
                                                <th class="text-right" style="padding-left:10px;font-size: 17px;">
                                                   <h4><b id="coupon_discount_amt" name="coupon_discount_amt">0.00</b></h4>
                                                </th>
                                             </tr>
                                             <tr>
                                                <th class="text-right" style="font-size: 17px;"><?= $this->lang->line('discount_on_all'); ?></th>
                                                <th class="text-right" style="padding-left:10px;font-size: 17px;">
                                                   <h4><b id="discount_to_all_amt" name="discount_to_all_amt">0.00</b></h4>
                                                </th>
                                             </tr>
                                             <tr style="<?= (!is_enabled_round_off()) ? 'display: none;' : '';?>">
                                                <th class="text-right" style="font-size: 17px;"><?= $this->lang->line('round_off'); ?>
                                                <i class="hover-q " data-container="body" data-toggle="popover" data-placement="top" data-content="Go to Site Settings-> Site -> Disable the Round Off(Checkbox)." data-html="true" data-trigger="hover" data-original-title="" title="Do you wants to Disable Round Off ?">
                                                      <i class="fa fa-info-circle text-maroon text-black hover-q"></i>
                                                    </i>
                                                  
                                                </th>
                                                <th class="text-right" style="padding-left:10px;font-size: 17px;">
                                                   <h4><b id="round_off_amt" name="tot_round_off_amt">0.00</b></h4>
                                                </th>
                                             </tr>
                                             <tr>
                                                <th class="text-right" style="font-size: 17px;"><?= $this->lang->line('grand_total'); ?></th>
                                                <th class="text-right" style="padding-left:10px;font-size: 17px;">
                                                   <h4><b id="total_amt" name="total_amt">0.00</b></h4>
                                                </th>
                                             </tr>
                                          </table>
                                       </div>
                                    </div>
                                 </div>
                              </div>

                              <div class="col-xs-12 ">
                                 <div class="col-xs-12">
                                       <div class="box-body ">
                                        <div class="col-xs-12">
                                          <div class="table-responsive" style="width:100%;">
                                          <table class="table table-hover table-bordered" style="width:100%" id="payments_table"><h4 class="box-title text-info"><?= $this->lang->line('previous_payments_information'); ?> : </h4>
                                             <thead>
                                                <tr class="bg-gray " >
                                                   <th>#</th>
                                                   <th><?= $this->lang->line('date'); ?></th>
                                                   <th><?= $this->lang->line('payment_type'); ?></th>
                                                   <th><?= $this->lang->line('payment_note'); ?></th>
                                                   <th><?= $this->lang->line('payment'); ?></th>
                                                   <th><?= $this->lang->line('action'); ?></th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                                <?php 
                                                  if(isset($sales_id)){
                                                    $q3 = $this->db->query("select * from db_salespayments where sales_id=$sales_id");
                                                    if($q3->num_rows()>0){
                                                      $i=1;
                                                      $total_paid = 0;
                                                      foreach ($q3->result() as $res3) {
                                                        echo "<tr class='text-center text-bold' id='payment_row_".$res3->id."'>";
                                                        echo "<td>".$i."</td>";
                                                        echo "<td>".show_date($res3->payment_date)."</td>";
                                                        echo "<td>".$res3->payment_type."</td>";
                                                        echo "<td>".$res3->payment_note."</td>";
                                                        echo "<td class='text-right' id='paid_amt_$i'>".store_number_format($res3->payment)."</td>";
                                                        echo '<td><i class="fa fa-trash text-red pointer" onclick="delete_payment('.$res3->id.')"> Delete</i></td>';
                                                        echo "</tr>";
                                                        $total_paid +=$res3->payment;
                                                        $i++;
                                                      }
                                                      echo "<tr class='text-right text-bold'><td colspan='4' >Total</td><td data-rowcount='$i' id='paid_amt_tot'>".store_number_format($total_paid)."</td><td></td></tr>";
                                                    }
                                                    else{
                                                      echo "<tr><td colspan='6' class='text-center text-bold'>No Previous Payments Found!!</td></tr>";
                                                    }

                                                  }
                                                  else{
                                                    echo "<tr><td colspan='6' class='text-center text-bold'>Payments Pending!!</td></tr>";
                                                  }
                                                ?>
                                             </tbody>
                                          </table>
                                          </div>
                                        </div>
                                       </div>
                                       <!-- /.box-body -->
                                    </div>
                                 <!-- /.box -->
                              </div>


                              <div class="col-xs-12 ">

                                 <div class="col-xs-12">



                                    <div class="col-xs-12">
                                       
                                       <!-- /.box-header -->
                                       <div class="box-body">
                                         

                                         <div class="box box-default collapsed-box">
                                       <div class="box-header with-border">
                                         <h3 class="box-title"><?= $this->lang->line('invoiceTermsAndConditions')?></h3>

                                         <div class="box-tools">
                                           <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus text-danger"></i>
                                           </button>
                                       </div>
                                    </div>
                                       <!-- /.box-header -->
                                       <div class="box-body">
                                        <textarea id="invoice_terms" name="invoice_terms" class="textarea" placeholder="Place some text here" style="width: 100%; height: 100px; font-size: 14px; border: 1px solid #dddddd; padding: 10px;"><?= $invoice_terms;?></textarea>
                                       </div>
                                       <!-- /.box-body -->
                                      
                                     </div>

                                       </div>
                                       <!-- /.box-body -->
                                    
                                     <!-- /.box -->
                                   </div>



                                       <div class="box-body ">

                                          <div class="col-xs-12 payments_div payments_div_">
                                            <h4 class="box-title text-info"><?= $this->lang->line('payment'); ?> : </h4>

                                            <div class="row">
                                                 <div class="col-xs-12">

                                                  <span for="">
                                                    <label>
                                                    <?= $this->lang->line('advance'); ?> : <label class='customer_tot_advance'></label>
                                                  </label>
                                                  </span>
                                                  
                                                  <div class="checkbox">
                                                    <label>
                                                      <input type="checkbox" id="allow_tot_advance" name="allow_tot_advance"> <?= $this->lang->line('adjust_advance_payment'); ?>
                                                    </label>
                                                  </div>
                                                 </div>
                                                  
                                              <div class="clearfix"></div>
                                          </div>
                                          <br>

                                          <div class="box box-solid bg-gray">
                                            <div class="box-body">
                                               
                                              <div class="row">
                                         
                                                <div class="col-xs-12">
                                                  <div class="">
                                                  <label for="amount"><?= $this->lang->line('amount'); ?></label>
                                                    <input type="text" class="form-control text-right paid_amt only_currency" id="amount" name="amount" placeholder="" >
                                                      <span id="amount_msg" style="display:none" class="text-danger"></span>
                                                </div>
                                               </div>
                                                <div class="col-xs-12">
                                                  <div class="">
                                                    <label for="payment_type"><?= $this->lang->line('payment_type'); ?></label>
                                                    <select class="form-control select2 payment-mode-select" id='payment_type' name="payment_type">
                                                      <option value=''>-Select-</option>
                                                      <?= get_payment_modes_select_list(get_current_store_id()); ?>
                                                    </select>
                                                    <span id="payment_type_msg" style="display:none" class="text-danger"></span>
                                                  </div>
                                                </div>
                                                <div class="col-xs-12">
                                                    <label for="account_id"><?= $this->lang->line('account'); ?></label>
                                                    <select class="form-control select2" id='account_id' name="account_id">
                                                      <option value="">-None-</option>
                                                        <?= get_accounts_select_list(get_store_details()->default_account_id);?>
                                                    </select>
                                                    <span id="account_id_msg" style="display:none" class="text-danger"></span>
                                                </div>
                                            <div class="clearfix"></div>
                                        </div>
                                        <div class="row payment-reference-row" style="display: none;">
                                            <div class="col-xs-12">
                                                <div class="">
                                                    <label for="payment_reference">Reference</label>
                                                    <input type="text" class="form-control" id="payment_reference" name="payment_reference" placeholder="Enter reference number...">
                                                    <span id="payment_reference_msg" style="display:none" class="text-danger"></span>
                                                </div>
                                            </div>
                                            <div class="col-xs-12">
                                                <div class="">
                                                    <label for="confirmation_status">Confirmation Status</label>
                                                    <select class="form-control" id="confirmation_status" name="confirmation_status">
                                                        <option value="1">Confirmed</option>
                                                        <option value="0">Pending</option>
                                                    </select>
                                                    <span id="confirmation_status_msg" style="display:none" class="text-danger"></span>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>

                                        <div class="row cheque_div" style="display: none;">
                                         
                                                <div class="col-xs-12">
                                                  <div class="">
                                                  <label for="cheque_number"><?= $this->lang->line('cheque_number'); ?></label>
                                                    <input type="text" class="form-control" id="cheque_number" name="cheque_number" placeholder="" >
                                                      <span id="cheque_number_msg" style="display:none" class="text-danger"></span>
                                                </div>
                                               </div>
                                                
                                               <div class="col-xs-12">
                                                  <div class="">
                                                  <label for="cheque_period"><?= $this->lang->line('cheque_period_days'); ?></label>
                                                    <input type="text" class="form-control only_currency" id="cheque_period" name="cheque_period" placeholder="" >
                                                      <span id="cheque_period_msg" style="display:none" class="text-danger"></span>
                                                </div>
                                               </div>

                                            <div class="clearfix"></div>
                                        </div> 

                                        <div class="row">
                                               <div class="col-xs-12">
                                                  <div class="">
                                                    <label for="payment_note"><?= $this->lang->line('payment_note'); ?></label>
                                                    <textarea type="text" class="form-control" id="payment_note" name="payment_note" placeholder="" ></textarea>
                                                    <span id="payment_note_msg" style="display:none" class="text-danger"></span>
                                                  </div>
                                               </div>
                                                
                                            <div class="clearfix"></div>
                                        </div>   
                                        </div>
                                        </div>
                                        </div><!-- -->
                                       </div>
                                       <!-- /.box-body -->
                                    </div>
                                 <!-- /.box -->
                              </div>

                              <!-- SMS Sender while saving -->
                                <?php 
                                   //Change Return
                                    $send_sms_checkbox='disabled';
                                    if($CI->is_sms_enabled()){
                                      if(!isset($sales_id)){
                                        $send_sms_checkbox='checked';  
                                      }else{
                                        $send_sms_checkbox='';
                                      }
                                    }

                              ?>
                             
                              <div class="col-xs-12 ">
                                 <div class="col-xs-12">
                                       <div class="box-body ">
                                          <div class="col-xs-12">
                                            <div class="checkbox icheck">
                                      <label>
                                        <input type="checkbox" <?=$send_sms_checkbox;?> class="form-control" id="send_sms" name="send_sms" > <label for="sales_discount" class=" control-label"><?= $this->lang->line('send_sms_to_customer'); ?>
                                          <i class="hover-q " data-container="body" data-toggle="popover" data-placement="top" data-content="If checkbox is Disabled! You need to enable it from SMS -> SMS API <br><b>Note:<i>Walk-in Customer will not receive SMS!</i></b>" data-html="true" data-trigger="hover" data-original-title="" title="Do you wants to send SMS ?">
                                  <i class="fa fa-info-circle text-maroon text-black hover-q"></i>
                                </i>
                                        </label>
                                      </label>
                                    </div>
                                        </div><!-- -->
                                       </div>
                                       <!-- /.box-body -->
                                    </div>
                                 <!-- /.box -->
                              </div> 
                           </div>
                           
                           <!-- /.box-body -->
                           <div class="box-footer">
                              <center>
                                <?php
                                if(isset($sales_id)){
                                  $btn_id='update';
                                  $btn_name="Update";
                                  echo '<input type="hidden" name="sales_id" id="sales_id" value="'.$sales_id.'"/>';
                                }
                                else{
                                  $btn_id='save';
                                  $btn_name="Save";
                                }

                                ?>
                                 <div class="col-xs-12 col-md-offset-3">
                                    <button type="button" id="<?php echo $btn_id;?>" class="btn btn-block btn-success payments_modal" title="Save Data"><?php echo $btn_name;?></button>
                                 </div>
                                 <div class="col-xs-12"><a href="<?= base_url()?>dashboard">
                                    <button type="button" class="btn btn-block btn-warning" title="Go Dashboard">Close</button>
                                  </a>
                                </div>
                              </center>
                           </div>
                           

                           <?= form_close(); ?>
                           <!-- OK END -->
                     </div>
                  </div>
                  <!-- /.box-footer -->
                 
               </div>
               <!-- /.box -->
             </section>
            <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
 <?php include"footer.php"; ?>
<!-- SOUND CODE -->
<?php include"comman/code_js_sound.php"; ?>
<!-- GENERAL CODE -->
<?php include"comman/code_js.php"; ?>

<script src="<?php echo $theme_link; ?>js/modals.js"></script>
<script src="<?php echo $theme_link; ?>js/modals/modal_item.js"></script>
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<script type="text/javascript">
  var walk_in_customer_name ='<?= get_walk_in_customer_name();?>';
  var walkin_customer_id = <?=json_encode($walkin_customer_id ?? null);?>;
  function isWalkInCustomer(){
    var cid = $(getCustomerSelectionId()).val();
    return (walkin_customer_id && cid == walkin_customer_id);
  }
</script>
<!-- Bootstrap WYSIHTML5 -->
<script src="<?php echo $theme_link; ?>plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>

<script src="<?php echo $theme_link; ?>js/sales.js?v=12"></script>  
<script src="<?php echo $theme_link; ?>js/ajaxselect/customer_select_ajax.js"></script>  
      <script>

         //Customer Selection Box Search
         function getCustomerSelectionId() {
           return '#customer_id';
         }

         $(document).ready(function () {

            var customer_id = "<?= (!empty($customer_id)) ? $customer_id : '';  ?>";

            autoLoadFirstCustomer(customer_id);

            // Toggle walk-in warning on customer change
            $("#customer_id").on('change', function(){
              if(isWalkInCustomer()){
                $("#walkin-warning").show();
              } else {
                $("#walkin-warning").hide();
              }
            });

         });
         //Customer Selection Box Search - END
         


         function save_operation() {
            <?php if($save_operation){ ?>
               return true;
            <?php }else{ ?>
               return false;
            <?php } ?>
         }

         $("#payment_type").on("change",function(){
          show_cheque_details();
        });
        function show_cheque_details(){
            var payment_type = $("#payment_type").val();
            var $selected = $("#payment_type option:selected");
            var requiresRef = $selected.data('requires-reference');
            var requiresConfirm = $selected.data('requires-confirmation');

            if(payment_type.toUpperCase()=='<?=strtoupper(cheque_name())?>'){
               $(".cheque_div").show();
            }
            else{
               $(".cheque_div").hide();
               $("#cheque_period,#cheque_number").val('');
            }

            if(requiresRef == 1 || requiresConfirm == 1){
               $(".payment-reference-row").show();
            } else {
               $(".payment-reference-row").hide();
               $("#payment_reference").val('');
               $("#confirmation_status").val('1');
            }
        }
        

       
        function set_previous_due(previous_due,tot_advance){
          $(".customer_previous_due").html(previous_due);
          $(".customer_tot_advance").html(tot_advance);
        }

        var base_url=$("#base_url").val();
        $("#store_id").on("change",function(){
          var store_id=$("#store_id").val();
          $.post(base_url+"sales/get_customers_select_list",{store_id:store_id},function(result){
              $("#customer_id").html('').append(result).select2();
              $("#sales_table > tbody").empty();
              calculate_tax();
          });
          $.post(base_url+"sales/get_tax_select_list",{store_id:store_id},function(result){
              $("#other_charges_tax_id").html('').append(result).select2();
              calculate_tax();
          });
        });

        /*Branch*/
        $("#warehouse_id").on("change",function(){
          var warehouse_id=$(this).val();
          $("#sales_table > tbody").empty();
          final_total();
        });
        /*Branch end*/

         $(".close_btn").on("click",function(){
           if(typeof swal === 'undefined'){
             if(!confirm('Are you sure you want to navigate away from this page?')) return;
             window.location='<?php echo $base_url; ?>dashboard';
           } else {
             swal({
               title: "Leave Page?",
               text: "Are you sure you want to navigate away from this page? Unsaved changes may be lost.",
               icon: "warning",
               buttons: true,
               dangerMode: true
             }).then(function(willLeave){
               if(willLeave) window.location='<?php echo $base_url; ?>dashboard';
             });
           }
         });
         //Initialize Select2 Elements
             $(".select2").select2();
         //Date picker
             $('.datepicker').datepicker({
               autoclose: true,
            format: 'dd-mm-yyyy',
              todayHighlight: true
             });
          
        /*if($("#warehouse_id").val()==''){
          $("#item_search").attr({
            disabled: true,
          });
          toastr["warning"]("Please Select Branch!!");
          failed.currentTime = 0; 
          failed.play();
         
        }*/
         
         /* ---------- CALCULATE TAX -------------*/
        

         function calculate_tax(i){ //i=Row
            set_tax_value(i);

           //Find the Tax type and Tax amount
           var tax_type = $("#tr_tax_type_"+i).val();
           var tax_amount = $("#td_data_"+i+"_11").val();

           var qty=$("#td_data_"+i+"_3").val();
           var sales_price=parseFloat($("#td_data_"+i+"_10").val());
           $("#td_data_"+i+"_4").val(sales_price);
           /*Discounr*/
           var discount_amt=$("#td_data_"+i+"_8").val();
               discount_amt   =(isNaN(parseFloat(discount_amt)))    ? 0 : parseFloat(discount_amt);

           var amt=parseFloat(qty) * sales_price;//Taxable

           var total_amt=amt-discount_amt;
           total_amt = (tax_type=='Inclusive') ? total_amt : parseFloat(total_amt) + parseFloat(tax_amount);
           
           //Set Unit cost
           $("#td_data_"+i+"_9").val('').val(to_Fixed(total_amt));
        
           final_total();
         }

        
         /* ---------- CALCULATE FSTR END -------------*/

         /*Calculate Coupon Discount Amount*/
         const discount_coupon_tot = function(subtotal) {
             var coupon_value=parseFloat($(".coupon_value").text());
                 coupon_value = isNaN(coupon_value) ? 0 : coupon_value;

             var coupon_type=$(".coupon_type").text();

             var discount_amt =0;
             if(coupon_type!='' && coupon_value>0){
                 if(coupon_type=='Percentage'){
                     discount_amt=(subtotal*coupon_value)/100;
                 }
                 else{//Fixed
                     discount_amt=coupon_value;
                 }
             }
             return discount_amt;
         }

         /* ---------- Final Description of amount ------------*/
         function final_total(){
           

           var rowcount=$("#hidden_rowcount").val();
           var subtotal=parseFloat(0);
           
           var other_charges_per_amt=parseFloat(0);
           var other_charges_total_amt=0;
           var taxable=0;
          if($("#other_charges_input").val()!=null && $("#other_charges_input").val()!=''){
             
              other_charges_tax_id =$('option:selected', '#other_charges_tax_id').attr('data-tax');
             other_charges_input=$("#other_charges_input").val();
             if(other_charges_tax_id>0){

               other_charges_per_amt=(other_charges_tax_id * other_charges_input)/100;
             }
             
             taxable=parseFloat(other_charges_per_amt)+parseFloat(other_charges_input);//Other charges input
             other_charges_total_amt=parseFloat(other_charges_per_amt)+parseFloat(other_charges_input);
           }
           else{
             //$("#other_charges_amt").html('0.00');
           }
           
         
           var tax_amt=0;
           var actual_taxable=0;
           var total_quantity=0;
         
           for(i=1;i<=rowcount;i++){
         
             if(document.getElementById("td_data_"+i+"_3")){
               //customer_id must exist
               if($("#td_data_"+i+"_3").val()!=null && $("#td_data_"+i+"_3").val()!=''){
                    actual_taxable=actual_taxable+ + +(parseFloat($("#td_data_"+i+"_13").val()) * parseFloat($("#td_data_"+i+"_3").val()));
                    subtotal=subtotal+ + +parseFloat($("#td_data_"+i+"_9").val());
                    if($("#td_data_"+i+"_7").val()>=0){
                      tax_amt=tax_amt+ + +$("#td_data_"+i+"_7").val();
                    }   
                    total_quantity +=parseFloat($("#td_data_"+i+"_3").val());
                }
                   
             }//if end
           }//for end
           
          
          //Show total Sales Quantitys
           $(".total_quantity").html(format_qty(total_quantity));

           //Apply Output on screen
           //subtotal
           if((subtotal!=null || subtotal!='') && (subtotal!=0)){
             
             //subtotal
             $("#subtotal_amt").html(to_Fixed(subtotal));
             
             //other charges total amount
             $("#other_charges_amt").html(to_Fixed(other_charges_total_amt));
             
             //other charges total amount
            

             taxable=taxable+subtotal;

             //Calculate Coupon Discount
             var coupon_amt = discount_coupon_tot(taxable);
               taxable-=coupon_amt;

             //discount_to_all_amt
            // if($("#discount_to_all_input").val()!=null && $("#discount_to_all_input").val()!=''){
                 var discount_input=parseFloat($("#discount_to_all_input").val());
                 discount_input = isNaN(discount_input) ? 0 : discount_input;
                 var discount=0;
                 if(discount_input>0){
                     var discount_type=$("#discount_to_all_type").val();
                     if(discount_type=='in_fixed'){
                       taxable-=discount_input;
                       discount=discount_input;
                       //Minus
                     }
                     else if(discount_type=='in_percentage'){
                         discount=(taxable*discount_input)/100;
                        taxable-=discount;
             
                     }
                 }
                 else{
                    //discount += $("#")
                 }
                   discount=parseFloat(discount);
                   
                    $("#coupon_discount_amt").html(to_Fixed(coupon_amt));  
                    $("#discount_to_all_amt").html(to_Fixed(discount));  
                    $("#hidden_discount_to_all_amt").val(to_Fixed(discount));  
             //}
             //subtotal_round=Math.round(taxable);
             subtotal_round=round_off(taxable);//round_off() method custom defined
             subtotal_diff=subtotal_round-taxable;
         
             $("#round_off_amt").html(to_Fixed(subtotal_diff)); 
             $("#total_amt").html(to_Fixed(subtotal_round)); 
             if(save_operation()){
               $("#amount").val(to_Fixed(subtotal_round));
             }
             $("#hidden_total_amt").val(to_Fixed(subtotal_round)); 
           }
           else{
             $("#subtotal_amt").html('0.00'); 
             $("#tax_amt").html('0.00'); 
             $("#round_off_amt").html('0.00'); 
             $("#total_amt").html('0.00'); 
             $("#hidden_total_amt").html('0.00'); 
             $("#discount_to_all_amt").html('0.00'); 
             $("#hidden_discount_to_all_amt").html('0.00'); 
             $("#subtotal_amt").html('0.00'); 
             $("#other_charges_amt").html('0.00');
               $("#amount").val('0.00');
           }
           
          // adjust_payments();
          //alert("final_total() end");
         }
         /* ---------- Final Description of amount end ------------*/
          
         function removerow(id){//id=Rowid
           
         $("#row_"+id).remove();
         final_total();
         failed.currentTime = 0;
        failed.play();
         }
               
     

    function enable_or_disable_item_discount(){
      /*var discount_input=parseFloat($("#discount_to_all_input").val());
      discount_input = isNaN(discount_input) ? 0 : discount_input;
      if(discount_input>0){
        $(".item_discount").attr({
          'readonly': true,
          'style': 'border-color:red;cursor:no-drop',
        });
      }
      else{
        $(".item_discount").attr({
          'readonly': false,
          'style': '',
        });
      }*/

      var rowcount=$("#hidden_rowcount").val();
      for(k=1;k<=rowcount;k++){
       if(document.getElementById("tr_item_id_"+k)){
         calculate_tax(k);
       }//if end
     }//for end

      //final_total();
    }

    

    //Sale Items Modal Operations Start
    function show_sales_item_modal(row_id){
      $('#sales_item').modal('toggle');
      $("#popup_tax_id").select2();

      //Find the item details
      var item_name = $("#td_data_"+row_id+"_1").html();
      var tax_type = $("#tr_tax_type_"+row_id).val();
      var tax_id = $("#tr_tax_id_"+row_id).val();
      var description = $("#description_"+row_id).val();

      /*Discount*/
      var item_discount_input = $("#item_discount_input_"+row_id).val();
      var item_discount_type = $("#item_discount_type_"+row_id).val();

      //Set to Popup
      $("#item_discount_input").val(item_discount_input);
      $("#item_discount_type").val(item_discount_type).select2();

      $("#popup_item_name").html(item_name);
      $("#popup_tax_type").val(tax_type).select2();
      $("#popup_tax_id").val(tax_id).select2();
      $("#popup_description").val(description);
      $("#popup_row_id").val(row_id);
    }

    function set_info(){
      var row_id = $("#popup_row_id").val();
      var tax_type = $("#popup_tax_type").val();
      var tax_id = $("#popup_tax_id").val();
      var description = $("#popup_description").val();
      var tax_name = ($('option:selected', "#popup_tax_id").attr('data-tax-value'));
      var tax = parseFloat($('option:selected', "#popup_tax_id").attr('data-tax'));

      /*Discounr*/
      var item_discount_input = $("#item_discount_input").val();
      var item_discount_type = $("#item_discount_type").val();

      //Set it into row 
      $("#item_discount_input_"+row_id).val(item_discount_input);
      $("#item_discount_type_"+row_id).val(item_discount_type);

      $("#tr_tax_type_"+row_id).val(tax_type);
      $("#tr_tax_id_"+row_id).val(tax_id);
      $("#tr_tax_value_"+row_id).val(tax);//%
      $("#description_"+row_id).val(description);
      $("#td_data_"+row_id+"_12").html(tax_name);
      
      calculate_tax(row_id);
      $('#sales_item').modal('toggle');
    }
    function set_tax_value(row_id){
      //get the sales price of the item
      var tax_type = $("#tr_tax_type_"+row_id).val();
      var tax = $("#tr_tax_value_"+row_id).val(); //%
      var qty=$("#td_data_"+row_id+"_3").val();
          qty = (isNaN(qty)) ? 0 :qty;
      var sales_price = parseFloat($("#td_data_"+row_id+"_10").val());
          sales_price = (isNaN(sales_price)) ? 0 :sales_price;
          sales_price = sales_price * qty;

      /*Discount*/
      var item_discount_type = $("#item_discount_type_"+row_id).val();
      var item_discount_input = parseFloat($("#item_discount_input_"+row_id).val());
          item_discount_input = (isNaN(item_discount_input)) ? 0 :item_discount_input;

      //Calculate discount      
      var discount_amt=(item_discount_type=='Percentage') ? ((sales_price) * item_discount_input)/100 : (item_discount_input*qty);
      sales_price-=parseFloat(discount_amt);

      var tax_amount = (tax_type=='Inclusive') ? calculate_inclusive(sales_price,tax) : calculate_exclusive(sales_price,tax);
      
      $("#td_data_"+row_id+"_8").val(to_Fixed(discount_amt));

      $("#td_data_"+row_id+"_11").val(to_Fixed(tax_amount));
    }
    //Sale Items Modal Operations End
      </script>


      <!-- UPDATE OPERATIONS -->
      <script type="text/javascript">
         <?php if(isset($sales_id) || isset($quotation_id)|| isset($order_id)){ ?> 
             $(document).ready(function(){
                var base_url='<?= base_url();?>';
                var path='';
                var id='';
                <?php if(isset($sales_id) && !empty($sales_id)) {?>
                  var id='<?=$sales_id;?>';  
                  var path = 'return_sales_list';
                <?php }?>

                <?php if(isset($quotation_id) && !empty($quotation_id)) {?>
                  var id='<?=$quotation_id;?>';  
                  var path = 'return_quotation_list';
                <?php }?>
   
                $(".box").append('<div class="overlay"><i class="fa fa-refresh fa-spin"></i></div>');
                $.post(base_url+"sales/"+path+"/"+id,{},function(result){
                //  alert(result);
                  $('#sales_table tbody').append(result);
                  $("#hidden_rowcount").val(parseInt(<?=$items_count;?>)+1);
                  success.currentTime = 0;
                  success.play();
                  get_coupon_details();  
                  enable_or_disable_item_discount();
                  $(".overlay").remove();
              }); 
             });
         <?php }?>
      </script>
      <script>
        $(function () {
          //bootstrap WYSIHTML5 - text editor
          //$("#invoice_terms").wysihtml5()
        })
      </script>
      <!-- UPDATE OPERATIONS end-->

      <!-- Make sidebar menu hughlighter/selector -->
      <script>$(".<?php echo basename(__FILE__,'.php');?>-active-li").addClass("active");</script>
      <script>
        $(function(){
          // Hide old AdminLTE header/sidebar on mobile
          $('.main-sidebar, .main-header, .content-header, .main-footer').hide();
          // Hide extra form fields
          var hideFields = ['#warehouse_id','#init_code','#count_id','#sales_date','#reference_no','#due_date','#other_charges_input','#other_charges_tax_id','#coupon_code','#discount_to_all_input','#discount_to_all_type','#sales_note'];
          $.each(hideFields, function(i, id){
            $(id).closest('.col-xs-12').hide().prev('label.control-label').hide();
          });
          // Hide previous due and coupon labels
          $('.customer_previous_due').closest('lable').hide();
          $('span.coupon_type').closest('.col-xs-12').hide();
          $('span.coupon_value').closest('.col-xs-12').hide();
          // Hide total rows except grand total
          $('#total_amt').closest('table').find('tr').not(':last').hide();
          // Style save button
          $('#save, #update').addClass('mp-save-btn').removeClass('btn-success btn-block');
          // Hide close button
          $('.box-footer .btn-warning').closest('.col-xs-12').hide();
        });
      </script>
      <?php $this->load->view('mobile/bottom_nav', ['active' => 'sale']); ?>
</body>
</html>
