<?php $this->load->view('reports/desktop/_styles'); ?>
<?php $CI =& get_instance(); ?>

<div class="mp-page-head">
  <div>
    <h2><?= htmlspecialchars($page_title); ?></h2>
    <div class="mp-page-sub">Track stock transfers between warehouses</div>
  </div>
  <div class="mp-report-actions">
    <?php $this->load->view('components/export_btn', ['tableId' => 'report-data']); ?>
  </div>
</div>

<form class="form-horizontal" id="report-form" onkeypress="return event.keyCode != 13;">
  <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
  <input type="hidden" id="base_url" value="<?php echo $base_url; ?>">

  <div class="mp-report-filter">
    <div class="mp-card-head"><h3>Report Filters</h3></div>
    <div class="mp-card-body">
      <div class="mp-form-grid">

        <?php if(store_module() && is_admin()): ?>
        <div class="mp-form-group full">
          <?php $this->load->view('store/store_code', ['show_store_select_box' => true, 'store_id' => get_current_store_id(), 'div_length' => '', 'show_all' => 'true', 'form_group_remove' => 'true']); ?>
        </div>
        <?php else: ?>
        <input type="hidden" name="store_id" id="store_id" value="<?= get_current_store_id(); ?>">
        <?php endif; ?>

        <div class="mp-form-group">
          <label for="from_warehouse"><?= $this->lang->line('from_warehouse'); ?></label>
          <select class="form-control select2" id="from_warehouse" name="from_warehouse" style="width:100%;">
            <?= get_warehouse_select_list(null); ?>
          </select>
          <span id="from_warehouse_msg" style="display:none" class="text-danger"></span>
        </div>

        <div class="mp-form-group">
          <label for="to_warehouse"><?= $this->lang->line('to_warehouse'); ?></label>
          <select class="form-control select2" id="to_warehouse" name="to_warehouse" style="width:100%;">
            <?= get_warehouse_select_list(null); ?>
          </select>
          <span id="to_warehouse_msg" style="display:none" class="text-danger"></span>
        </div>

        <div class="mp-form-group">
          <label for="category_id"><?= $this->lang->line('category'); ?></label>
          <select class="form-control select2" id="category_id" name="category_id" style="width:100%;">
            <option value="">-All-</option>
            <?= get_categories_select_list(null, get_current_store_id()); ?>
          </select>
          <span id="category_id_msg" style="display:none" class="text-danger"></span>
        </div>

        <div class="mp-form-group">
          <label for="brand_id"><?= $this->lang->line('brand'); ?></label>
          <select class="form-control select2" id="brand_id" name="brand_id" style="width:100%;">
            <option value="">-All-</option>
            <?= get_brands_select_list(null, get_current_store_id()); ?>
          </select>
          <span id="brand_id_msg" style="display:none" class="text-danger"></span>
        </div>

        <div class="mp-form-group">
          <label for="item_id"><?= $this->lang->line('item_name'); ?></label>
          <select class="form-control select2" id="item_id" name="item_id" style="width:100%;"></select>
          <span id="item_id_msg" style="display:none" class="text-danger"></span>
        </div>

        <div class="mp-form-group">
          <label for="from_date"><?= $this->lang->line('from_date'); ?></label>
          <div class="input-group date">
            <div class="input-group-addon"><i class="fa fa-calendar"></i></div>
            <input type="text" class="form-control pull-right datepicker" id="from_date" name="from_date" value="<?php echo show_date(date('d-m-Y')); ?>">
          </div>
          <span id="Sales_date_msg" style="display:none" class="text-danger"></span>
        </div>

        <div class="mp-form-group">
          <label for="to_date"><?= $this->lang->line('to_date'); ?></label>
          <div class="input-group date">
            <div class="input-group-addon"><i class="fa fa-calendar"></i></div>
            <input type="text" class="form-control pull-right datepicker" id="to_date" name="to_date" value="<?php echo show_date(date('d-m-Y')); ?>">
          </div>
          <span id="Sales_date_msg" style="display:none" class="text-danger"></span>
        </div>

      </div>

      <div class="mp-report-filter-actions" style="margin-top:20px;">
        <button type="button" id="view" class="mp-btn-primary" title="Show Report"><i class="fa fa-eye"></i> Show</button>
        <a href="<?= base_url('dashboard'); ?>">
          <button type="button" class="mp-btn-secondary close_btn" title="Go Dashboard"><i class="fa fa-times"></i> Close</button>
        </a>
      </div>
    </div>
  </div>
</form>

<div class="mp-report-results">
  <div class="mp-card-head"><h3><?= $this->lang->line('records_table'); ?></h3></div>
  <div class="box-body">
    <div class="mp-dt-scroll">
      <table class="table table-bordered table-hover" id="report-data" style="width:100%;">
        <thead>
          <tr class="bg-blue">
            <th>#</th>
            <?php if(store_module() && is_admin()): ?>
            <th><?= $this->lang->line('store_name'); ?></th>
            <?php endif; ?>
            <th><?= $this->lang->line('transfer_date'); ?></th>
            <th><?= $this->lang->line('from_warehouse'); ?></th>
            <th><?= $this->lang->line('to_warehouse'); ?></th>
            <th><?= $this->lang->line('item_name'); ?></th>
            <th><?= $this->lang->line('category_name'); ?></th>
            <th><?= $this->lang->line('brand_name'); ?></th>
            <th><?= $this->lang->line('quantity'); ?></th>
          </tr>
        </thead>
        <tbody id="tbodyid">
        </tbody>
      </table>
    </div>
  </div>
</div>

<script src="<?php echo $theme_link; ?>js/ajaxselect/item_select_ajax.js"></script>
<script>function getItemSelectionId() { return '#item_id'; }</script>
<script type="text/javascript">
  var base_url = $("#base_url").val();
  $("#store_id").on("change", function(){
    var store_id = $(this).val();
    autoLoadFirstItem();
    load_category_list();
    load_brand_list();
    $.post(base_url + "sales/get_warehouse_select_list", { store_id: store_id }, function(result){
      result = '<option value="">All</option>' + result;
      $("#from_warehouse,#to_warehouse").html('').append(result).select2();
    });
  });

  $("#category_id").on("change", function(){
    autoLoadFirstItem();
  });

  function load_category_list(){
    var store_id = $("#store_id").val();
    $.post(base_url + "sales/get_categories_select_list", { store_id: store_id }, function(result){
      result = '<option value="">All</option>' + result;
      $("#category_id").html('').append(result).select2();
    });
  }

  function load_brand_list(){
    var store_id = $("#store_id").val();
    $.post(base_url + "sales/get_brands_select_list", { store_id: store_id }, function(result){
      result = '<option value="">All</option>' + result;
      $("#brand_id").html('').append(result).select2();
    });
  }

  function load_records(){
    $(".mp-report-results").append('<div class="overlay"><i class="fa fa-refresh fa-spin"></i></div>');
    data = new FormData($('#report-form')[0]);
    if(!xss_validation(data)){ return false; }
    $("#view").attr('disabled', true);
    $.ajax({
      type: 'POST',
      url: base_url + 'reports/show_stock_transfer_report',
      data: data,
      cache: false,
      contentType: false,
      processData: false,
      success: function(result){
        $("#tbodyid").empty().append(result);
        $("#view").attr('disabled', false);
        $(".overlay").remove();
      }
    });
  }

  $("#view").on("click", function(){
    check_field("from_date");
    check_field("to_date");
    load_records();
  });

  function check_field(id){
    if(!$("#" + id).val()){
      $('#' + id + '_msg').fadeIn(200).show().html('Required Field').addClass('required');
      flag = false;
    } else {
      $('#' + id + '_msg').fadeOut(200).hide();
    }
  }
</script>
<script>$(".report-stock-transfer-active-li").addClass("active");</script>
