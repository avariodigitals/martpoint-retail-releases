<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Units_model extends CI_Model {

	var $table = 'db_units';

	public function __construct() {
		parent::__construct();
	}
	var $column_order = array('unit_name','description','status','store_id'); //set column field database for datatable orderable
	var $column_search = array('unit_name','description','status','store_id'); //set column field database for datatable searchable 
	var $order = array('id' => 'desc'); // default order 

	private function _get_datatables_query()
	{
		
		$this->db->from($this->table);
		//if not admin
		//if(!is_admin()){
			$this->db->where("store_id",get_current_store_id());
		//}

		$i = 0;
	
		foreach ($this->column_search as $item) // loop column 
		{
			if(isset($_POST['search']['value']) && !empty($_POST['search']['value'])) // if datatable send POST for search
			{
				
				if($i===0) // first loop
				{
					$this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
					$this->db->like($item, $_POST['search']['value']);
				}
				else
				{
					$this->db->or_like($item, $_POST['search']['value']);
				}

				if(count($this->column_search) - 1 == $i) //last loop
					$this->db->group_end(); //close bracket
			}
			$i++;
		}
		
		if(isset($_POST['order']) && isset($_POST['order']['0']['column']) && isset($_POST['order']['0']['dir'])) // here order processing
		{
			$this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
		} 
		else if(isset($this->order))
		{
			$order = $this->order;
			$this->db->order_by(key($order), $order[key($order)]);
		}
	}

	function get_datatables()
	{
		$this->_get_datatables_query();
		if(isset($_POST['length']) && $_POST['length'] != -1)
		$this->db->limit($_POST['length'], $_POST['start']);
		$query = $this->db->get();
		return $query->result();
	}

	function count_filtered()
	{
		$this->_get_datatables_query();
		$query = $this->db->get();
		return $query->num_rows();
	}

	public function count_all()
	{
		$this->db->where("store_id",get_current_store_id());
		$this->db->from($this->table);
		return $this->db->count_all_results();
	}


	public function verify_and_save(){
		$unit_name = $this->input->post('unit_name', TRUE);
		$description = $this->input->post('description', TRUE);
		$parent_unit_id = $this->input->post('parent_unit_id', TRUE) ?: null;
		$conversion_factor = $this->input->post('conversion_factor', TRUE);
		$is_default = $this->input->post('is_default') ? 1 : 0;
		$store_id=(store_module() && is_admin()) ? $store_id : get_current_store_id();
		//Validate This units already exist or not
		$this->db->where("upper(unit_name)", strtoupper($unit_name));
		$this->db->where('store_id', $store_id);
		$query = $this->db->get('db_units');
		if($query->num_rows()>0){
			return "This Units Name Already Exist.";

		}
		else{
			$info = array(
		    				'store_id' 				=> $store_id,
		    				'unit_name' 				=> $unit_name,
		    				'description' 				=> $description,
																				'parent_unit_id' 								=> $parent_unit_id,
																				'conversion_factor' 							=> !empty($conversion_factor) ? (float)$conversion_factor : 1,
																				'status' 										=> 1,
		    			);
			if($this->db->field_exists('is_default','db_units')){
				$info['is_default'] = $is_default;
			}

			$q1 = $this->db->insert('db_units', $info);
			if ($q1){
				if($is_default && $this->db->field_exists('is_default','db_units')){
					$this->_clear_other_defaults($this->db->insert_id(), $store_id);
				}
					$this->session->set_flashdata('success', 'Success!! Unit Name Added Successfully!');
			        return "success";
			}
			else{
			        return "failed";
			}
		}
	}

	/**
	 * Remove the default flag from every other unit in the same store.
	 * Keeps the "one default per store" invariant intact.
	 */
	private function _clear_other_defaults($keep_id, $store_id){
		if(!$this->db->field_exists('is_default','db_units')){ return; }
		$this->db->where('id !=', $keep_id);
		$this->db->where('store_id', $store_id);
		$this->db->update('db_units', array('is_default' => 0));
	}

	//Get units_details
	public function get_details($id,$data){
		//Validate This units already exist or not
		$query=$this->db->query("select * from db_units where upper(id)=upper('$id')");
		if($query->num_rows()==0){
			show_404();exit;
		}
		else{
			$query=$query->row();
			$data['q_id']=$query->id;
			$data['unit_name']=$query->unit_name;
			$data['description']=$query->description;
			$data['parent_unit_id']=$query->parent_unit_id;
			$data['conversion_factor']=$query->conversion_factor;
			$data['store_id']=$query->store_id;
			$data['is_default']=isset($query->is_default) ? (int)$query->is_default : 0;
			return $data;
		}
	}
	public function update_unit(){
		$q_id = $this->input->post('q_id', TRUE);
		$unit_name = $this->input->post('unit_name', TRUE);
		$description = $this->input->post('description', TRUE);
		$parent_unit_id = $this->input->post('parent_unit_id', TRUE) ?: null;
		$conversion_factor = $this->input->post('conversion_factor', TRUE);
		$is_default = $this->input->post('is_default') ? 1 : 0;
		$store_id=(store_module() && is_admin()) ? $store_id : get_current_store_id();
		//Validate This units already exist or not
		$this->db->where("upper(unit_name)", strtoupper($unit_name));
		$this->db->where("id !=", $q_id);
		$this->db->where('store_id', $store_id);
		$query = $this->db->get('db_units');
		if($query->num_rows()>0){
			return "This units Name already Exist.";
			
		}
		else{
			$info = array(
	    																				'unit_name' 								=> $unit_name, 
	    																				'description' 								=> $description,
	    																				'parent_unit_id' 								=> $parent_unit_id,
	    																				'conversion_factor' 							=> !empty($conversion_factor) ? (float)$conversion_factor : 1,
	    																				'status' 										=> 1,
	    																				);
			if($this->db->field_exists('is_default','db_units')){
				$info['is_default'] = $is_default;
			}

			$info['store_id']=(store_module() && is_admin()) ? $store_id : get_current_store_id();

			$q1 = $this->db->where('id',$q_id)->where('store_id',$store_id)->update('db_units', $info);

			if ($q1){
				if($is_default && $this->db->field_exists('is_default','db_units')){
					$this->_clear_other_defaults($q_id, $store_id);
				}
					$this->session->set_flashdata('success', 'Success!! units Updated Successfully!');
			        return "success";
			}
			else{
			        return "failed";
			}
		}
	}
	public function update_status($id,$status){
       if (set_status_of_table($id,$status,'db_units')){
            echo "success";
        }
        else{
            echo "failed";
        }
	}
	public function delete_unit($id){
		$tot_rec = $this->db->select("count(*) as tot")->where("store_id",get_current_store_id())->where("unit_id in($id)")->get("db_items")->row()->tot;
		if($tot_rec>0){
			echo "Can't Delete! Already used to add Items.";exit;
		}
		$this->db->where("id",$id);
		//if not admin
		if(!is_admin()){
			$this->db->where("store_id",get_current_store_id());
		}

		$query1=$this->db->delete("db_units");
        if ($query1){
            echo "success";
        }
        else{
            echo "failed";
        }
	}


}
