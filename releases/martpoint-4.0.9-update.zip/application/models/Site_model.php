<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class Site_model extends CI_Model {
    public function get_details(){
		$data=$this->data;

		//Validate This suppliers already exist or not
		$query=$this->db->query("select * from db_sitesettings order by id asc limit 1");
		if($query->num_rows()==0){
			show_404();exit;
		}
		else{
			/* QUERY 1*/
			$query=$query->row();
			$data['q_id']=$query->id;
            $data['site_name']=$query->site_name;
            $data['logo']=$query->logo;
            $data['sales_target']=$query->sales_target ?? 0;
			return $data;
		}
	}
	public function update_site(){
		$site_name = $this->input->post('site_name', TRUE);
		$change_return = $this->input->post('change_return', TRUE);
		$round_off = $this->input->post('round_off', TRUE);
		$q_id = $this->input->post('q_id', TRUE);

		$sales_target = (float)$this->input->post('sales_target', TRUE);
		//echo "<pre>";print_r($this->security->xss_clean(html_escape(array_merge($this->data,$_POST))));exit();
				
		
		$logo='';
		if(!empty($_FILES['logo']['name'])){
			$site_upload_path = FCPATH . 'uploads/site/';
			if(!is_dir($site_upload_path)){
				@mkdir($site_upload_path, 0775, true);
			}
			$config['upload_path']          = $site_upload_path;
	        $config['allowed_types']        = 'gif|jpg|png';
	        $config['max_size']             = 500;
	        $config['max_width']            = 500;
	        $config['max_height']           = 500;

	        $this->load->library('upload', $config);

	        if ( ! $this->upload->do_upload('logo'))
	        {
	                $error = array('error' => $this->upload->display_errors());
	                print($error['error']);
	                exit();
	        }
	        else
	        {
	        	   $logo_name=$this->upload->data('file_name');
	        		$logo=" ,logo='/uploads/site/$logo_name' ";
	        }
		}
        
		$change_return = (isset($change_return)) ? 1 : 0;
		$round_off = (isset($round_off)) ? 1 : 0;
        $info = array('site_name' => $site_name);
        $info['sales_target'] = $sales_target;
        if(!empty($logo_name)){
            $info['logo'] = '/uploads/site/'.$logo_name;
        }
        $query1 = $this->db->where('id', $q_id)->update('db_sitesettings', $info);
      
		if ($query1){
		    return "success";
		}
		else{
		    return "failed";
		}
	}
}

/* End of file Site_model.php */
