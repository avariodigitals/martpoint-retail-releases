$(document).on("click", "#save, #update", function (e) {
	var base_url=$("#base_url").val();
    //Initially flag set true
    var flag=true;

    function check_field(id)
    {

      if(!$("#"+id).val() ) //Also check Others????
        {

            $('#'+id+'_msg').fadeIn(200).show().html('Required Field').addClass('required');
            //$('#'+id).css({'background-color' : '#E8E2E9'});
            flag=false;
        }
        else
        {
             $('#'+id+'_msg').fadeOut(200).hide();
             //$('#'+id).css({'background-color' : '#FFFFFF'});    //White color
        }
    }

    //Sync first barcode row into hidden general fields before validation
    // Only sync when the barcode/unit table actually exists — otherwise we would
    // zero out the visible simple-pricing inputs (#price, #sales_price, etc.)
    function syncBarcodeToHiddenFields(){
        var $firstPprice = $('input[name="barcode_pprice[]"]').first();
        if($firstPprice.length === 0){
            return; // Barcode table not visible — nothing to sync
        }
        var pprice = parseFloat($firstPprice.val()) || 0;
        var sprice = parseFloat($('input[name="barcode_sprice[]"]').first().val()) || 0;
        var mrp    = parseFloat($('input[name="barcode_mrp[]"]').first().val()) || 0;
        var batch  = $('input[name="barcode_batch[]"]').first().val() || '';
        var qty    = parseFloat($('input[name="barcode_qty[]"]').first().val()) || 0;
        var barcode = $('input[name="barcode_barcode[]"]').first().val() || '';
        var expire  = $('input[name="barcode_expire_date[]"]').first().val() || '';
        var mfg     = $('input[name="barcode_mfg_date[]"]').first().val() || '';

        var tax = parseFloat($('option:selected', "#tax_id").attr('data-tax')) || 0;
        var tax_type = $("#tax_type").val();
        var price = pprice;
        if(tax_type == 'Exclusive' && tax > 0){
            price = pprice / (1 + tax/100);
        }

        $("#purchase_price").val(to_Fixed(pprice));
        $("#sales_price").val(to_Fixed(sprice));
        $("#mrp").val(to_Fixed(mrp));
        $("#batch_lot").val(batch);
        $("#adjustment_qty").val(to_Fixed(qty));
        $("#price").val(to_Fixed(price));
        $("#custom_barcode").val(barcode);
        $("#expire_date").val(expire);
        $("#mfg_date").val(mfg);

        var profit_margin = (pprice > 0) ? ((sprice - pprice) / pprice * 100) : 0;
        $("#profit_margin").val(to_Fixed(profit_margin));
    }
    syncBarcodeToHiddenFields();

    var item_group = $("#item_group").val();
    var item_type_val = $('input[name="item_type"]:checked').val() || $('#item_type_hidden').val() || 'item';
    var is_service = (item_type_val === 'service');
    //Validate Input box or selection box should not be blank or empty
	check_field("item_name");
	check_field("category_id");
	if(!is_service){
		check_field("unit_id");//units of measurments
	}
	//check_field("alert_qty");
	check_field("tax_id");
	check_field("tax_type");
	//check_field("profit_margin");
	if(item_group=='Single'){
		// Validate barcode table prices (primary price entry point)
		var $bc_pprice = $('input[name="barcode_pprice[]"]').first();
		var $bc_sprice = $('input[name="barcode_sprice[]"]').first();
		var $bc_mrp    = $('input[name="barcode_mrp[]"]').first();
		var bc_pprice_val = parseFloat($bc_pprice.val()) || 0;
		var bc_sprice_val = parseFloat($bc_sprice.val()) || 0;
		var bc_mrp_val    = parseFloat($bc_mrp.val()) || 0;

		var bc_has_data = ($bc_pprice.length > 0); // table exists if first pprice input exists
		if(bc_has_data){
			// Barcode table is visible — prices MUST be entered in the first row
			if(bc_pprice_val <= 0 || bc_sprice_val <= 0 || bc_mrp_val <= 0){
				$('#barcode_table_msg').fadeIn(200).show();
				$('#barcode_table_msg_text').html('Purchase Price, Wholesale Price, and Retail Price are required for the first unit row.');
				if(bc_pprice_val <= 0) $bc_pprice.focus();
				else if(bc_sprice_val <= 0) $bc_sprice.focus();
				else $bc_mrp.focus();
				flag = false;
			} else {
				$('#barcode_table_msg').fadeOut(200).hide();
			}
		} else {
			// No barcode table visible — fall back to hidden fields
			if(!$('#purchase_price').val() || !$('#sales_price').val() || !$('#price').val()){
				toastr["warning"]("Please fill Purchase Price, Sales Price and Item Price.");
				flag = false;
			}
		}
	}
	else{
		if(!validate_variants_records()){
			//toastr["warning"]("You have Missed Something to Variants Fields!");
			return;
		}	
	}
	
	
    if(flag==false)
    {
		toastr["warning"]("You have Missed Something to Fillup!");
		return;
    }

    var this_id=this.id;

    var existing_row_count=0;
    if(item_group=='Variants'){
    	var existing_row_count = $("#variant_table tbody tr").length;
    	if(existing_row_count==0){
    		toastr["warning"]("No Records in Variants List!!");
    		return;
    	}
    }


    if(this_id=="save")  //Save start
    {

					///if(confirm("Do You Wants to Save Record ?")){
						e.preventDefault();
						// Sync barcode row prices into hidden fields before capturing FormData
						if(typeof syncBarcodeToHiddenFields === 'function'){
							syncBarcodeToHiddenFields();
						}
						data = new FormData($('#items-form')[0]);//form name
						/*Check XSS Code*/
						if(!xss_validation(data)){ return false; }

						$(".box").append('<div class="overlay"><i class="fa fa-refresh fa-spin"></i></div>');
						$("#"+this_id).attr('disabled',true);  //Enable Save or Update button

						// Determine if saving a service or an item
						var itemType = $('input[name="item_type"]:checked').val() || $('#item_type_hidden').val() || 'item';
						var saveUrl = (itemType === 'service') ? base_url+'services/newservices' : base_url+'items/newitems?existing_row_count='+existing_row_count;

						$.ajax({
						type: 'POST',
						url: saveUrl,
						data: data,
						cache: false,
						contentType: false,
						processData: false,
						success: function(result){
              //alert(result);return;
							if(result=="success")
							{
								//alert("Record Saved Successfully!");
								var itemType = $('input[name="item_type"]:checked').val() || $('#item_type_hidden').val() || 'item';
								window.location=base_url+'items';//"items-view.php";
								return;
							}
							else if(result=="failed")
							{
							   toastr["error"]("Sorry! Failed to save Record.Try again!");
							   //	return;
							}
							else
							{
								toastr["error"](result);

							}
							$("#"+this_id).attr('disabled',false);  //Enable Save or Update button
							$(".overlay").remove();

					   },
					   error: function(xhr){
					   	   toastr["error"](xhr.responseText || "Server error. Please refresh and try again.");
					   	   $("#"+this_id).attr('disabled',false);
					   	   $(".overlay").remove();
					   }
					   });
				///}
				return;
				//e.preventDefault


    }//Save end
	
	else if(this_id=="update")  //Save start
    {
				
					///if(confirm("Do You Wants to Update Record ?")){
						e.preventDefault();
						// Sync barcode row prices into hidden fields before capturing FormData
						if(typeof syncBarcodeToHiddenFields === 'function'){
							syncBarcodeToHiddenFields();
						}
						data = new FormData($('#items-form')[0]);//form name3
						/*Check XSS Code*/
						if(!xss_validation(data)){ return false; }
						
						$(".box").append('<div class="overlay"><i class="fa fa-refresh fa-spin"></i></div>');
						$("#"+this_id).attr('disabled',true);  //Enable Save or Update button

						// Determine if updating a service or an item
						var itemType = $('input[name="item_type"]:checked').val() || $('#item_type_hidden').val() || 'item';
						var updateUrl = (itemType === 'service') ? base_url+'services/update_services' : base_url+'items/update_items?existing_row_count='+existing_row_count;

						$.ajax({
						type: 'POST',
						url: updateUrl,
						data: data,
						cache: false,
						contentType: false,
						processData: false,
						success: function(result){
              //alert(result);return;
							if(result=="success")
							{
								window.location=base_url+'items';
							}
							else if(result=="failed")
							{
							   toastr["error"]("Sorry! Failed to save Record.Try again!");
							}
							else
							{
								  toastr["error"](result);
							}
							$("#"+this_id).attr('disabled',false);  //Enable Save or Update button
							$(".overlay").remove();
							return;
					   },
					   error: function(xhr){
					   	   toastr["error"](xhr.responseText || "Server error. Please refresh and try again.");
					   	   $("#"+this_id).attr('disabled',false);
					   	   $(".overlay").remove();
					   }
					   });
				///}

				//e.preventDefault


    }//Save end
	

});


//On Enter Move the cursor to desigtation Id
function shift_cursor(kevent,target){

    if(kevent.keyCode==13){
		$("#"+target).focus();
    }
	
}

//update status start
function update_status(id,status)
{
	var base_url=$("#base_url").val();
	$.post(base_url+"items/update_status",{id:id,status:status},function(result){
		if(result=="success")
				{
					 toastr["success"]("Status Updated Successfully!");
				  //alert("Status Updated Successfully!");
				  success.currentTime = 0; 
				  success.play();
				  if(status==0)
				  {
					  status="Inactive";
					  var span_class="label label-danger";
					  $("#span_"+id).attr('onclick','update_status('+id+',1)');
				  }
				  else{
					  status="Active";
					   var span_class="label label-success";
					   $("#span_"+id).attr('onclick','update_status('+id+',0)');
					  }

				  $("#span_"+id).attr('class',span_class);
				  $("#span_"+id).html(status);
				  return false;
				}
				else if(result=="failed"){
					toastr["error"]("Failed to Update Status.Try again!");
				  failed.currentTime = 0; 
				  failed.play();

				  return false;
				}
				else{
					toastr["error"](result);
				  failed.currentTime = 0; 
				  failed.play();
				  return false;
				}
	});
}
//update status end
function removerow_also_delete_from_database(item_id,rowid){
	if(item_id==''){
		removerow(rowid);
		return;
	}
	else{
		var base_url=$("#base_url").val();
		$(".box").append('<div class="overlay"><i class="fa fa-refresh fa-spin"></i></div>');
	    $.post(base_url+"items/delete_items",{q_id:item_id},function(result){
	   //alert(result);return;
		   if(result=="success")
					{
					  toastr["success"]("Record Deleted Successfully!");
					  removerow(rowid);
					}
					else if(result=="failed"){
					  toastr["error"]("Failed to Delete .Try again!");
					}
					else{
					   toastr["error"](result);
					}
					$(".overlay").remove();
					return false;
	   });

	}
}

//Delete Record start
function delete_items(q_id)
{
   swal({
     title: "Are you sure?",
     text: "You want to delete this record?",
     icon: "warning",
     buttons: ["Cancel", "Yes, Delete"],
     dangerMode: true,
   }).then(function(willDelete){
     if(willDelete){
       $(".box").append('<div class="overlay"><i class="fa fa-refresh fa-spin"></i></div>');
       $.post($("#base_url").val()+"items/delete_items",{q_id:q_id},function(result){
         if(result=="success")
         {
           toastr["success"]("Record Deleted Successfully!");
           $('#example2').DataTable().ajax.reload();
         }
         else if(result=="failed"){
           toastr["error"]("Failed to Delete .Try again!");
         }
         else{
           toastr["error"](result);
         }
         $(".overlay").remove();
         return false;
       });
     }
   });
}
//Delete Record end
function multi_delete(){
	var base_url=$("#base_url").val();
    var this_id=this.id;
    
   swal({
     title: "Are you sure?",
     text: "You want to delete selected records?",
     icon: "warning",
     buttons: ["Cancel", "Yes, Delete"],
     dangerMode: true,
   }).then(function(willDelete){
     if(willDelete){
       $(".box").append('<div class="overlay"><i class="fa fa-refresh fa-spin"></i></div>');
       $("#"+this_id).attr('disabled',true);
       data = new FormData($('#table_form')[0]);
       $.ajax({
         type: 'POST',
         url: base_url+'items/multi_delete',
         data: data,
         cache: false,
         contentType: false,
         processData: false,
         success: function(result){
           if(result=="success")
           {
             toastr["success"]("Record Deleted Successfully!");
             success.currentTime = 0;
             success.play();
             $('#example2').DataTable().ajax.reload();
             $(".delete_btn").hide();
             $(".group_check").prop("checked",false).iCheck('update');
           }
           else if(result=="failed")
           {
             toastr["error"]("Sorry! Failed to save Record.Try again!");
             failed.currentTime = 0;
             failed.play();
           }
           else
           {
             toastr["error"](result);
             failed.currentTime = 0;
             failed.play();
           }
           $("#"+this_id).attr('disabled',false);
           $(".overlay").remove();
         }
       });
     }
   });
}

//CALCULATED PURCHASE PRICE
function calculate_purchase_price(){
	var price = get_float_type_data("#price");
	var tax = (isNaN(parseFloat($('option:selected', "#tax_id").attr('data-tax')))) ? 0 :parseFloat($('option:selected', "#tax_id").attr('data-tax'));
	tax = parseFloat(tax);

	var tax_type = $("#tax_type").val();
	var purchase_price = parseFloat(0);

	console.log('tax='+tax);
	if(tax_type=='Inclusive'){
			purchase_price = price;
	}
	else{
		purchase_price = (price + (price*tax)/parseFloat(100));
	}
	//$("#purchase_price").val( (price + (price*tax)/parseFloat(100)).toFixed(decimals));

	$("#purchase_price").val(to_Fixed(purchase_price));
	//calculate_sales_price();

	//$("#purchase_price").val( (price + (price*tax)/parseFloat(100)).toFixed(2));
	//calculate_sales_price();
	calculate_sales_price();
}
$(document).on("keyup", "#price", function(event) {
	calculate_purchase_price();
});
$(document).on("change", "#tax_id", function(event) {
	calculate_purchase_price();
});

//CALCUALATED SALES PRICE
function calculate_sales_price(){
	var price = get_float_type_data("#price");
	var profit_margin = get_float_type_data("#profit_margin");

	var profit_amt = (profit_margin/100) * price;

	var sales_price = price + profit_amt;

	$("#sales_price").val(to_Fixed(sales_price));
	//calculate_profit_margin();
}
$(document).on("change", "#tax_type", function(event) {
	calculate_purchase_price();
});
$(document).on("change", "#profit_margin", function(event) {
	calculate_sales_price();
});
//END
//CALCULATE PROFIT MARGIN PERCENTAGE
function calculate_profit_margin(){
	var price = get_float_type_data("#price");
	var sales_price = get_float_type_data("#sales_price");
	var profit_margin = (sales_price-price);
	var profit_margin = (profit_margin/price)*parseFloat(100);
	$("#profit_margin").val(to_Fixed(profit_margin));
}
$(document).on("change", "#sales_price", function(event) {
	calculate_profit_margin();
});
//END

/*function delete_stock_entry(entry_id){
 if(confirm("Do You Wants to Delete Record ?")){
    var base_url=$("#base_url").val();
    $(".box").append('<div class="overlay"><i class="fa fa-refresh fa-spin"></i></div>');
   $.post(base_url+"items/delete_stock_entry",{entry_id:entry_id,item_id:$("#q_id").val()},function(result){
   //alert(result);//return;
   result=result;
     if(result=="success")
        { 
          location.reload(true);
        }
        else if(result=="failed"){
          toastr["error"]("Failed to Delete .Try again!");
          failed.currentTime = 0; 
          failed.play();
        }
        else{
          toastr["error"](result);
          failed.currentTime = 0; 
          failed.play();
        }
        $(".overlay").remove();
   });
   }//end confirmation   
  }*/

  function view_warehouse_wise_stock_item(item_id){
  	  var base_url=$("#base_url").val();
	  $.post(base_url+'warehouse/view_warehouse_wise_stock_item', {item_id: item_id}, function(result) {
	    $(".view_warehouse_wise_stock_item").html('').html(result);
	    $('#view_warehouse_wise_stock_item_model').modal('toggle');
	  });
	}

$("#variant_search").autocomplete({
    source: function(data, cb){
        $.ajax({
        	autoFocus:true,
            url: $("#base_url").val()+'items/get_json_variant_details',
            method: 'GET',
            dataType: 'json',
            /*showHintOnFocus: true,
			autoSelect: true, 
			
			selectInitial :true,*/
			
            data: {
                name: data.term,
            },
            beforeSend: function() {
                if($("#tax_id").val()==''){
                  toastr['warning']("Please Select Tax Type!");
                  $("#tax_id").select2('open');
                  $("#variant_search").removeClass('ui-autocomplete-loading');
                  return;
                }
                $("#variant_search").addClass('ui-autocomplete-loading');
            },
            success: function(res){
              //console.log(res);
                var result;
                result = [
                    {
                        label: 'No Records Found ',
                        value: ''
                    }
                ];

                if (res.length) {
                    result = $.map(res, function(el){
                        return {
                            label: el.variant_name + " - "+el.description,
                            value: '',
                            id: el.id,
                            //item_name: el.value,
                        };
                    });
                }

                cb(result);
            }
        });
    },
     response:function(e,ui){
          /*if(ui.content.length==1){
            $(this).data('ui-autocomplete')._trigger('select', 'autocompleteselect', ui);
            $(this).autocomplete("close");
          }*/
          //console.log(ui.content[0].id);
        },
        //loader start
        search: function (e, ui) {
        },
        select: function (e, ui) { 
            if(typeof ui.content!='undefined'){
              console.log("Autoselected first");
              if(isNaN(ui.content[0].id)){
                return;
              }
              var item_id=ui.content[0].id;
            }
            else{
              var variant_id=ui.item.id;
            }
            //console.log(variant_id);
            return_variant_data_in_row(variant_id);  
            $("#variant_search").val('');            
        },   
        //loader end
});
function return_variant_data_in_row(variant_id){
  $("#variant_search").addClass('ui-autocomplete-loader-center');
  var base_url=$("#base_url").val();
  var rowcount=$("#variant_table tbody tr").length;
  $.post(base_url+"items/return_variant_data_in_row/"+rowcount+"/"+variant_id,{},function(result){
        //alert(result);
        console.log("Result = "+result);

        $('#variant_table tbody').append(result);
        $("#hidden_rowcount").val($("#variant_table tbody tr").length);
        success.currentTime = 0;
        success.play();
        //enable_or_disable_item_discount();
        $("#variant_search").removeClass('ui-autocomplete-loader-center');
        $("#variant_search").removeClass('ui-autocomplete-loading');
    }); 
}

function removerow(id){//id=Rowid
	$("#row_"+id).remove();
	$("#row_"+id+"_batch").remove();
	//final_total();
	failed.currentTime = 0;
	failed.play();
}


 function calculate_purchase_price_of_all_row(){
   var rowcount=$("#variant_table tbody tr").length;     
 
   for(i=1;i<=rowcount;i++){
 
     if(document.getElementById("td_data_"+i+"_3")){
       var price = get_float_type_data("#td_data_"+i+"_3");
       var purchase_price = calculate_purchase_price_new(price);//get_float_type_data("#td_data_"+i+"_4");
      // var profit_margin = get_float_type_data("#td_data_"+i+"_5");
       //var sales_price   = get_float_type_data("#td_data_"+i+"_6");

       $("#td_data_"+i+"_4").val(purchase_price);
           
     }//if end
   }//for end
   calculate_sales_price_of_all_row();
 }
function calculate_purchase_price_new(price){
	var tax = (isNaN(parseFloat($('option:selected', "#tax_id").attr('data-tax')))) ? 0 :parseFloat($('option:selected', "#tax_id").attr('data-tax')); 
		tax = parseFloat(tax);
	var tax_type = $("#tax_type").val();
	purchase_price = (tax_type=='Inclusive') ? price : parseFloat(price)+parseFloat(calculate_exclusive(price,tax));
	//purchase_price = parseFloat(purchase_price)+parseFloat(price);;
	return to_Fixed(purchase_price);
}

function calculate_sales_price_of_all_row(){
   var rowcount=$("#variant_table tbody tr").length;     
 
   for(i=1;i<=rowcount;i++){
     if(document.getElementById("td_data_"+i+"_3")){
       //var price = get_float_type_data("#td_data_"+i+"_3");
       var price = get_float_type_data("#td_data_"+i+"_3");
       var profit_margin = get_float_type_data("#td_data_"+i+"_5");
       var sales_price   = calculate_sales_price_new(price,profit_margin);

       var $td6 = $("#td_data_"+i+"_6");
       if(profit_margin > 0 || $td6.val().trim() == ''){
         $td6.val(sales_price);
       }
           
     }//if end
   }//for end
 }

function calculate_sales_price_new(price,profit_margin){
	var tax = (isNaN(parseFloat($('option:selected', "#tax_id").attr('data-tax')))) ? 0 :parseFloat($('option:selected', "#tax_id").attr('data-tax')); 
		tax = parseFloat(tax);

	var profit_amt = (profit_margin/100) * price;

	var sales_price = price + profit_amt;

	return to_Fixed(sales_price);
}


function calculate_profit_margin_of_all_row(){
   var rowcount=$("#variant_table tbody tr").length;     
 
   for(i=1;i<=rowcount;i++){
     if(document.getElementById("td_data_"+i+"_3")){
       //var price = get_float_type_data("#td_data_"+i+"_3");
       var price = get_float_type_data("#td_data_"+i+"_4");
       var sales_price   = get_float_type_data("#td_data_"+i+"_6");
       var profit_margin = calculate_profit_margin_new(price,sales_price);

       $("#td_data_"+i+"_5").val(profit_margin);
           
     }//if end
   }//for end
 }
function calculate_profit_margin_new(price,sales_price){
	var profit_margin = (sales_price-price);
	var profit_margin = (profit_margin/price)*parseFloat(100);
	return to_Fixed(profit_margin);
}

$(document).on("change", "#item_group", function(event) {
	var item_group = $("#item_group").val();
	if(item_group=='Variants'){
		$("#barcode_section").hide();
		$("#hsn,#sku,#custom_barcode").parent().addClass('hide');
		$(".variant_div").show();
	}
	else{
		$("#barcode_section").show();
		$("#hsn,#sku,#custom_barcode").parent().removeClass('hide');
		$(".variant_div").hide();
	}
});

$(document).on("change", "#tax_id, #tax_type", function(event) {
	calculate_purchase_price_of_all_row();
	calculate_sales_price_of_all_row();
});

function validate_variants_records(){
   var rowcount=$("#variant_table tbody tr").length;
   var available_rows=0;
   for(i=1;i<=rowcount;i++){
     if(document.getElementById("td_data_"+i+"_3")){
     	available_rows++;

       var price = get_float_type_data("#td_data_"+i+"_3");
       var sales_price = get_float_type_data("#td_data_"+i+"_6");

       if(price==0 || sales_price==0){
      	   $("#td_data_"+i+"_3").focus();
      	   toastr["warning"]("Variants Price & Sales Price is Required!");
           return false;
       }
     }//if end
   }//for end
   if(available_rows==0){
   	toastr["warning"]("No Records in Variants List!!");
   	return false;
   }
   return true;
 }
function calculateBarcodeProfit(row){
    var pprice = parseFloat($(row).find('input[name="barcode_pprice[]"]').val()) || 0;
    var sprice = parseFloat($(row).find('input[name="barcode_sprice[]"]').val()) || 0;
    var mrp    = parseFloat($(row).find('input[name="barcode_mrp[]"]').val()) || 0;

    var wholesaleMargin = (pprice > 0) ? ((sprice - pprice) / pprice * 100).toFixed(2) : 0;
    var wholesaleProfit = (sprice - pprice).toFixed(2);
    $(row).find('.wholesale-profit').text('Profit: ' + wholesaleMargin + '% — ' + wholesaleProfit);

    var retailMargin = (pprice > 0) ? ((mrp - pprice) / pprice * 100).toFixed(2) : 0;
    var retailProfit = (mrp - pprice).toFixed(2);
    $(row).find('.retail-profit').text('Profit: ' + retailMargin + '% — ' + retailProfit);
}

// Auto-calculate profit indicators when any barcode price changes
$(document).on('change keyup', '#barcode_table input[name="barcode_pprice[]"], #barcode_table input[name="barcode_sprice[]"], #barcode_table input[name="barcode_mrp[]"]', function(){
    var row = $(this).closest('tr');
    calculateBarcodeProfit(row);
    syncBarcodeToHiddenFields();
});

// Initialize profit indicators on page load
function initBarcodeProfitIndicators(){
    $('#barcode_table tbody tr').each(function(){
        calculateBarcodeProfit(this);
    });
}
initBarcodeProfitIndicators();

$(document).ready(function() {
  $(window).keydown(function(event){
    if(event.keyCode == 13) {
      event.preventDefault();
      return false;
    }
  });
});