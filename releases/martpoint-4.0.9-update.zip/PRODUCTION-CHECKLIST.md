# MartPoint Retail - Production Checklist

## Version
**v4.0.5** | Codebase: `martpoint-retail-source`

## Pre-Launch Verification
- [x] Source version bumped to `4.0.5` in `MY_Controller.php`
- [x] All migrations present (4.0.0 through 4.0.5)
- [x] Backup files removed from models directory
- [x] Test controller (`Example.php`) removed
- [x] Dead code removed (`Category_model_new.php`, `Store_profile_model.php.new`)
- [x] Empty directories removed (`saas_views/`)
- [x] Root directory cleaned (scripts moved to `scripts/`)
- [x] Duplicate Service Packages placeholder removed (real implementation retained)
- [x] README.md updated to v4.0.5
- [x] FEATURE_CHECKLIST.md updated with accurate status

---

## Pre-Deployment Checklist

### 1. Logo & Branding
- [ ] Log in as admin
- [ ] Navigate to **Sidebar -> Store -> Store Settings**
- [ ] Upload **MartPoint Retail** logo (recommended: 200x60px PNG with transparent background)
- [ ] Verify logo displays correctly on:
  - [ ] Login page
  - [ ] Sidebar header (`.logo-lg`)
  - [ ] POS navbar brand
  - [ ] Invoice/receipt print views

### 2. Full Manual QA - Desktop

| Screen | Action | Expected Result |
|---|---|---|
| Login | Open `/login` | Dark gradient background, white card, orange button |
| Login | Enter credentials and submit | Successful login, dashboard loads, no console errors |
| Dashboard | View main dashboard | Sidebar dark gray, navbar white, cards white with shadows |
| Dashboard | Click Today/Weekly/Monthly/Yearly/All filters | Active button state styled correctly, data updates |
| Dashboard | Scroll down to graphs/tables | Tables styled with clean headers, rounded cards |
| POS | Open `/pos` | Dark top navbar, item cards with hover lift effect |
| POS | Search/select an item | Item added to cart, totals update, `.tot_grand` styled |
| POS | Click "Hold" invoice | Hold list dropdown styled, invoice saved |
| POS | Complete a sale | Payment modal opens with dark `.header-custom` header |
| Sales List | Open `/sales` | DataTables search + pagination styled, no overflow |
| Add Sale | Open `/sales/add` | Form inputs have orange focus ring, Select2 rounded |
| Add Item | Open `/items/add` | Same form styling consistency |
| Add Customer | Click "Add Customer" in any modal | Modal header dark, form clean |
| Invoice | View any generated invoice | Clean layout, readable tables |
| Reports | Open any report page | Tables and pagination styled correctly |
| Business Profile | Open Business Profile | Industry type, business model, feature flags visible |
| Operations | Enable a workflow (e.g. Kitchen) | Operations menu appears in sidebar |
| Logout | Click Sign Out | Returns to login page, session cleared |

### 3. Full Manual QA - Mobile (Chrome DevTools or real device)

| Screen | Action | Expected Result |
|---|---|---|
| Login | Viewport 375px width | Card fits screen, no horizontal scroll |
| Dashboard | Toggle sidebar via hamburger | Sidebar slides in with shadow, no layout breakage |
| Dashboard | Scroll through cards | Cards stack vertically, padding correct |
| POS | Viewport 375px width | Item grid scrollable, totals visible |
| POS | Open navbar menu | Collapses into hamburger, links tappable |
| Sales List | View table | Horizontal scroll works, no clipped text |
| Add Sale | Tap form inputs | iOS: no unwanted zoom; Android: inputs tappable |
| Kitchen (Restaurant) | Open mobile/operations then Kitchen | Mobile KDS loads, status tabs tappable, updates work |
| Table Management (Restaurant) | Open mobile/operations then Tables | Table grid loads, quick-status toggle works |
| Offline | Toggle network off in DevTools | Offline badge appears, sync button visible |
| Offline | Create sale while offline | Sale queued in IndexedDB |
| Online | Toggle network back on | Queued sale syncs automatically |

### 4. Browser Console Check
- [ ] Open DevTools (F12) on every major page
- [ ] Confirm **zero red console errors** on:
  - [ ] Login
  - [ ] Dashboard
  - [ ] POS
  - [ ] Sales list
  - [ ] Add sale form
  - [ ] Invoice view
  - [ ] Business Profile
  - [ ] Operations (any workflow)

### 5. Receipt / Print Preview Test
- [ ] Open a completed sale invoice
- [ ] Click "Print" or open browser print preview (Ctrl+P / Cmd+P)
- [ ] Verify:
  - [ ] Content is readable
  - [ ] No dark backgrounds bleeding into print
  - [ ] Tables print without collapsed borders
- [ ] If thermal printer available, print a test receipt and confirm readability

### 6. POS Full Sale Flow
- [ ] Open POS
- [ ] Add 3+ items to cart
- [ ] Apply discount
- [ ] Select customer
- [ ] Click "Pay"
- [ ] Select payment method (Cash/Card/etc.)
- [ ] Complete transaction
- [ ] Verify invoice generates with correct styling
- [ ] Hold an invoice, then retrieve it from Hold List
- [ ] Verify hold list table styled correctly

### 7. User Roles & Permissions
- [ ] Log in as **Admin** - confirm all menus visible
- [ ] Log in as **Salesperson** - confirm only permitted menus visible
- [ ] Log in as **Accounts** - confirm restricted access
- [ ] Verify sidebar active states highlight correctly per role
- [ ] Verify Business Profile feature flags hide/show correct operations

### 8. Industry Adaptation Engine
- [ ] Set industry type to "Restaurant" - verify Kitchen Display, Table Management, and dashboard FOH cards appear on desktop and mobile
- [ ] Set industry type to "Laundry" - verify Laundry Workflow appears
- [ ] Set industry type to "Salon" - verify Treatment Notes appears
- [ ] Set industry type to "Pharmacy" - verify Expiry Alerts prominent
- [ ] Reset to "General Retail" - verify only standard modules appear

### 9. Database & Backup
- [ ] Run database backup
- [ ] Verify backup completes without errors
- [ ] Confirm all 4.0.0-4.0.5 migrations applied (check `db_schema_migrations` table)
- [ ] Verify `db_store` modular tables exist (11 tables)

### 10. Auto-Update System
- [ ] Verify update channel URL is correct in Site Settings
- [ ] Test "Check for Updates" - should report "already up to date" at v4.0.5
- [ ] Verify rollback capability exists

### 11. Screenshots for Website / Demo
Capture the following at 1920x1080 and 390x844 (iPhone 14):
- [ ] **Login page** (desktop + mobile)
- [ ] **Dashboard** with widgets (desktop + mobile)
- [ ] **POS screen** with items and cart (desktop + mobile)
- [ ] **Sales list** with DataTables (desktop)
- [ ] **Invoice view** (desktop)
- [ ] **Business Profile** with industry presets (desktop)
- [ ] **Operations** workflow (e.g. Kitchen or Laundry) (desktop)
- [ ] **Mobile sidebar** open state (mobile)
- [ ] **Offline mode** badge and sync (mobile)

---

## Rollback Plan

If critical issues are found during QA:

```bash
cd /Users/ralphmore/Herd/martpointretailapp

# View recent commits
git log --oneline -10

# Revert to last known good commit
git checkout <commit-hash> -- .
```

**What changed in v4.0.5 cleanup:**
- Version bumped in `MY_Controller.php`
- 18 backup files removed from `application/models/`
- `Example.php` test controller removed
- `saas_views/` empty directory removed
- `Category_model_new.php` dead code removed
- 50+ fix/debug/migration scripts moved to `scripts/`
- 26 audit report directories moved to `scripts/audit_reports/`
- Duplicate Service Packages placeholder removed from Operations
- `README.md` and `FEATURE_CHECKLIST.md` updated

**What did NOT change:**
- No database schema changes
- No controller/model logic changes (except removing placeholder `packages()` method)
- No JavaScript changes
- No CSS changes

---

## Known Limitations (Not Blockers)

1. `change-login-password2.php` uses Bootstrap 4.5.2 with its own `login.css`. Intentionally excluded to avoid framework conflicts.
2. Receipt/print views use inline thermal-printer-optimized styles and were left untouched.
3. iCheck checkboxes use `square/orange.css` (close to accent but not exact match). Functional.
4. `dashboard2.php` second-row info-boxes have hardcoded left border colors. Acceptable visual variety.
5. **Price Catalogue** is fully implemented — category filter, search, inline price editing, CSV export.
6. **Production Workflow** standalone page is now a functional dashboard linking to existing production batches, recipes, and reports.

---

## Sign-Off

| Role | Name | Date | Status |
|---|---|---|---|
| QA Tester | | | |
| Product Owner | | | |
| Deployer | | | |

**Final Decision:**
- [ ] **GO** - Deploy to production
- [ ] **NO-GO** - Issues found, revert and retry
