================================================================================
  MARTPOINT v4.0.9.2 COMPLETE UPDATE PACKAGE
  FOR EXISTING INSTALLATIONS (4.0.8 -> 4.0.9.2)
================================================================================

This ZIP contains EVERY file that changed between 4.0.8 and 4.0.9.2.
477 files. Nothing is left out.

--------------------------------------------------------------------------------
DEPLOYMENT STEPS (20 minutes)
--------------------------------------------------------------------------------

1. BACKUP FIRST! (CRITICAL)
   mysqldump -u USER -p DBNAME > martpoint_backup.sql
   tar -czf martpoint_backup.tar.gz /path/to/martpoint

2. RUN DATABASE MIGRATIONS (in phpMyAdmin or MySQL)

   Option A: Run the single combined file (recommended):
   mysql -u USER -p DBNAME < martpoint-4.0.9-database.sql

   Option B: Run individual migrations in order:
   mysql -u USER -p DBNAME < release_build/migrations/4.0.8_to_4.0.9_compatibility.sql
   mysql -u USER -p DBNAME < release_build/migrations/4.0.8_to_4.0.9_holditems_staff_commission.sql
   mysql -u USER -p DBNAME < release_build/migrations/4.0.9_to_4.0.9.2_promotions_loyalty.sql

   All migrations are idempotent (safe to run multiple times).
   All work on MySQL 5.5/5.7 AND MariaDB.

   Verify:
   mysql -u USER -p DBNAME -e "DESCRIBE db_salesitems;" | grep commission
   mysql -u USER -p DBNAME -e "DESCRIBE db_promotions;" | grep mode
   mysql -u USER -p DBNAME -e "DESCRIBE db_loyalty_settings;" | grep referral

3. UPLOAD ALL FILES

   Using SCP:
   scp -r .htaccess sw.js application/ theme/ setup/ updates/ scripts/ \
       release_build/ user@host:/path/to/martpoint/

   Using FTP:
   Upload ALL files preserving directory structure.
   DO NOT upload application/config/database.php (not in this zip).

4. CLEAR CACHE (CRITICAL)
   rm -rf /path/to/martpoint/application/cache/*
   rm -rf /path/to/martpoint/application/logs/log-*.php

5. CLEAR BROWSER CACHE (CRITICAL)
   Hard refresh: Ctrl+Shift+R (Windows) or Cmd+Shift+R (Mac)

6. TEST
   - Login
   - POS (new desktop interface)
   - Mobile POS (items save correctly, split payments work)
   - PayPlan/BNPL (down payment method selector)
   - Administration (modernized UI)
   - Marketing > Loyalty (referral program)
   - Marketing > Promotions (advanced mode)
   - Reports (desktop views)
   - Online store
   - Check error logs

--------------------------------------------------------------------------------
NOT INCLUDED (do NOT overwrite):
  application/config/database.php   <- Your DB credentials
  application/config/config.php     <- Your base URL + encryption key

--------------------------------------------------------------------------------
ROLLBACK
--------------------------------------------------------------------------------
  Database: mysql -u USER -p DBNAME < martpoint_backup.sql
  Files:   tar -xzf martpoint_backup.tar.gz -C /

================================================================================
